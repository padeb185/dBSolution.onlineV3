
from core.pays import nom_pays_tenant, pays_tenant_defaut
from core.suppression import analyser_suppression
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import ProtectedError, RestrictedError
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.generic import ListView
from adresse.models import Adresse
from django.utils.translation import gettext as _, gettext_noop
from assurance.models import Assurance
from assurance.forms import AssuranceForm
from adresse.forms import AdresseForm
from assurance_police.models import AssurancePolice
from utilisateurs.models import UserLog
from utils.securite import peut_supprimer, refuser_suppression


@method_decorator([login_required, never_cache], name='dispatch')
class AssuranceListView(ListView):
    model = Assurance
    template_name = "assurance/assurance_list.html"
    context_object_name = "assurances"
    ordering = ["nom_compagnie"]

    def get_queryset(self):
        societe = self.request.user.societe
        return Assurance.objects.filter(societe=societe)



@never_cache
@login_required
def assurance_detail(request, assurance_id):
    tenant = request.user.societe

    assurance = get_object_or_404(Assurance, id=assurance_id, societe=tenant)
    adresse = assurance.adresse

    return render(
        request,
        "assurance/assurance_detail.html",
        {
            "assurance": assurance,
            "adresse": adresse,
        },
    )



@login_required
def ajouter_assurance_all(request):
    tenant = request.user.societe

    if request.method == "POST":

        form_assurance = AssuranceForm(request.POST)

        # -------------------------
        # DONNÉES ADRESSE
        # -------------------------
        adresse_data = {
            "rue": request.POST.get("rue", "").strip(),
            "numero": request.POST.get("numero", "").strip(),
            "code_postal": request.POST.get("code_postal", "").strip(),
            "ville": request.POST.get("ville", "").strip(),
            "pays": (request.POST.get("pays") or nom_pays_tenant()).strip(),
            "code_pays": (request.POST.get("code_pays") or pays_tenant_defaut()).strip(),
            "societe": tenant,
        }

        # -------------------------
        # VALIDATION ADRESSE
        # -------------------------
        if not all([
            adresse_data["rue"],
            adresse_data["numero"],
            adresse_data["code_postal"],
            adresse_data["ville"],
        ]):

            messages.error(
                request,
                _("Les champs d'adresse (rue, numéro, code postal, ville) sont obligatoires.")
            )

        elif form_assurance.is_valid():

            with transaction.atomic():

                # -------------------------
                # CRÉATION ADRESSE
                # -------------------------
                adresse = Adresse.objects.create(**adresse_data)

                # -------------------------
                # CRÉATION ASSURANCE
                # -------------------------
                assurance = form_assurance.save(commit=False)

                assurance.adresse = adresse
                assurance.societe = tenant

                assurance.save()

                messages.success(
                    request,
                    _("Assurance '%(nom_compagnie)s' créée avec succès !") % {"nom_compagnie": assurance.nom_compagnie}
                )
                return redirect(
                    f"{reverse('assurance:assurance_list')}?saved=1"
                )

        else:

            messages.error(
                request,
                _("Le formulaire contient des erreurs.")
            )

    else:

        form_assurance = AssuranceForm()

    return render(
        request,
        "assurance/assurance_form.html",
        {
            "form": form_assurance,
        },
    )




@login_required
def modifier_assurance(request, assurance_id):
    tenant = request.user.societe


    # Récupérer l'assureur et son adresse liée
    assurance = get_object_or_404(
        Assurance.objects.select_related("adresse"),
        id=assurance_id
    )
    adresse = assurance.adresse

    if request.method == "POST":
        # Formulaires pour Assurance et Adresse
        form_assurance = AssuranceForm(request.POST, instance=assurance)
        form_adresse = AdresseForm(request.POST, instance=adresse)

        if form_assurance.is_valid() and form_adresse.is_valid():
            # Sauvegarde adresse puis mise à jour de l'assurance
            adresse = form_adresse.save()
            assurance = form_assurance.save(commit=False)
            assurance.adresse = adresse
            assurance.save()

            messages.success(request, _("Assurance et adresse mises à jour avec succès."))

            return redirect(
                f"{reverse('assurance:assurance_detail', kwargs={'assurance_id': assurance.id})}?saved=1"
            )
        else:
            messages.error(request, _("Le formulaire contient des erreurs."))
    else:
        # Pré-remplissage des formulaires
        form_assurance = AssuranceForm(instance=assurance)
        form_adresse = AdresseForm(instance=adresse)

    return render(
        request,
        "assurance/modifier_assurance.html",
        {
            "form": form_assurance,
            "form_adresse": form_adresse,
            "assurance": assurance,
            "adresse": adresse,
        }
    )





@never_cache
@login_required
def dashboard_assurance_view(request):
    user = request.user

    assurance = Assurance.objects.all()
    assurance_police = AssurancePolice.objects.all()

    context = {
        "user": user,
        "societe": getattr(user, "societe", None),
        "total_assurance": assurance.count(),
        "total_assurance_police": assurance_police.count(),
        "assurance": assurance,
        "assurance_police": assurance_police,
    }

    return render(
        request,
        "assurance/dashboard_assurance.html",
        context,
    )







ACTION_SUPPRESSION_ASSURANCE = gettext_noop("Suppression de l'assurance")


@login_required
def delete_assurance_view(request, pk):
    if not peut_supprimer(request.user):
        return refuser_suppression(request)

    assurance = get_object_or_404(
        Assurance.objects.select_related("adresse", "societe"),
        pk=pk,
    )

    analyse = analyser_suppression(assurance)
    objets_bloquants = analyse["bloquants"]
    objets_supprimes = analyse["supprimes"]

    if request.method == "POST":
        nom = assurance.nom_compagnie or _("Assurance")

        if objets_bloquants:
            messages.error(
                request,
                _("Impossible de supprimer « %(nom)s » : elle est encore liée à d'autres éléments.") % {"nom": nom},
            )
            return redirect("assurance:delete_assurance", pk=pk)

        # Libellé pour le log (capturé AVANT la suppression)
        nom_log = assurance.nom_compagnie or f"#{assurance.pk}"
        courtier = " ".join(filter(None, [assurance.courtier_prenom, assurance.courtier_nom]))
        if courtier:
            nom_log += f" (courtier : {courtier})"
        nb_supprimes = sum(len(objets) for _label, objets in objets_supprimes)
        if nb_supprimes:
            detail = ", ".join(f"{len(objets)} {label}" for label, objets in objets_supprimes)
            nom_log += f" – supprimé(s) en cascade : {detail}"

        try:
            with transaction.atomic():
                assurance.delete()

                UserLog.objects.create(
                    utilisateur=request.user,
                    action=f"{ACTION_SUPPRESSION_ASSURANCE} : {nom_log}",
                )
        except (ProtectedError, RestrictedError):
            messages.error(
                request,
                _("Impossible de supprimer « %(nom)s » : elle est encore liée à d'autres éléments.") % {"nom": nom},
            )
            return redirect("assurance:delete_assurance", pk=pk)

        messages.success(request, _("L'assurance « %(nom)s » a bien été supprimée.") % {"nom": nom})

        return redirect(
            f"{reverse('assurance:assurance_list')}?deleted=1"
        )

    return render(
        request,
        "assurance/delete_assurance.html",
        {
            "assurance": assurance,
            "objets_supprimes": objets_supprimes,
            "objets_bloquants": objets_bloquants,
        },
    )