from django.urls import path

from . import admin_web

app_name = "particulier_admin"

urlpatterns = [
    path("", admin_web.tableau, name="tableau"),
    path("comptes/<uuid:pk>/", admin_web.compte, name="compte"),
    path("comptes/<uuid:pk>/activer/", admin_web.compte_activer, name="compte_activer"),
    path("comptes/<uuid:pk>/supprimer/", admin_web.compte_supprimer, name="compte_supprimer"),
    path("fichiers/<str:modele>/<str:pk>/<str:champ>/", admin_web.fichier, name="fichier"),
]
