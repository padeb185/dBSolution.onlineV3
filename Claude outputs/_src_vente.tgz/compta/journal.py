"""
Journal général (débit / crédit) – consolidation des écritures PCMN de l'application :
ventes, encaissements, achats, salaires (et leur paiement), versements ONSS / précompte,
instructeurs indépendants, immobilisations (acquisitions, amortissements, cessions),
variations de stock et mouvements de trésorerie encodés à la main.
"""
import calendar
from collections import OrderedDict
from datetime import date
from decimal import Decimal

from django.utils.translation import gettext as _, gettext_lazy

ZERO = Decimal("0.00")

SOURCES = OrderedDict([
    ("vente", gettext_lazy("Ventes")),
    ("encaissement", gettext_lazy("Encaissements")),
    ("achat", gettext_lazy("Achats")),
    ("salaire", gettext_lazy("Salaires")),
    ("paiement_salaire", gettext_lazy("Paiement des salaires")),
    ("versement_social", gettext_lazy("Versements ONSS / précompte")),
    ("instructeur", gettext_lazy("Instructeurs indépendants")),
    ("reversement", gettext_lazy("Reversements aux propriétaires (locations)")),
    ("immobilisation", gettext_lazy("Immobilisations et amortissements")),
    ("financement", gettext_lazy("Financement des véhicules (crédit, leasing, renting)")),
    ("stock", gettext_lazy("Stock")),
    ("tresorerie", gettext_lazy("Trésorerie (mouvements manuels)")),
    ("ouverture", gettext_lazy("Soldes d'ouverture des comptes de trésorerie")),
    ("od", gettext_lazy("Opérations diverses (OD)")),
])


def _dans(jour, debut, fin):
    return jour is not None and (debut is None or jour >= debut) and (fin is None or jour <= fin)


def _norm(l, source, piece="", journal=None, jour=None):
    return {
        "date": jour or l.get("date"), "journal": journal or l.get("journal", "OD"), "piece": piece or l.get("piece", ""),
        "compte": l["compte"], "intitule": str(l.get("intitule") or ""), "libelle": str(l.get("libelle") or ""),
        "debit": Decimal(l.get("debit") or 0), "credit": Decimal(l.get("credit") or 0), "source": source,
    }


def ecritures_societe(societe, debut=None, fin=None, sources=None):
    sources = set(sources or SOURCES.keys())
    E = []

    # ---- Ventes et encaissements
    try:
        from facture.models import Facture, PaiementFacture
        from facture.paiements import ecritures_paiement
        if "vente" in sources:
            qs = Facture.objects.filter(societe=societe, statut=Facture.Statut.EMISE, client_est_societe=False)
            if debut:
                qs = qs.filter(issue_date__gte=debut)
            if fin:
                qs = qs.filter(issue_date__lte=fin)
            for f in qs:
                lib = f"{f.numero} – {f.nom_client_courant()}"
                base = {"libelle": lib, "date": f.issue_date}
                if f.type_document == Facture.TypeDocument.NOTE_CREDIT:
                    # Note de crédit : écriture inverse de la facture (clients au crédit, ventes et TVA au débit)
                    lib = f"{f.numero} – {_('Note de crédit')} – {f.nom_client_courant()}"
                    base = {"libelle": lib, "date": f.issue_date}
                    E.append(_norm(dict(base, compte="400000", intitule=_("Clients"), credit=f.total), "vente", f.numero, "VEN"))
                    E.append(_norm(dict(base, compte="700000", intitule=_("Chiffre d'affaires – ventes"), debit=f.total_ht), "vente", f.numero, "VEN"))
                    if f.total_tva:
                        E.append(_norm(dict(base, compte="451000", intitule=_("TVA à payer"), debit=f.total_tva), "vente", f.numero, "VEN"))
                    continue
                E.append(_norm(dict(base, compte="400000", intitule=_("Clients"), debit=f.total), "vente", f.numero, "VEN"))
                E.append(_norm(dict(base, compte="700000", intitule=_("Chiffre d'affaires – ventes"), credit=f.total_ht), "vente", f.numero, "VEN"))
                if f.total_tva:
                    E.append(_norm(dict(base, compte="451000", intitule=_("TVA à payer"), credit=f.total_tva), "vente", f.numero, "VEN"))
        if "encaissement" in sources:
            qs = PaiementFacture.objects.filter(facture__societe=societe).select_related("facture")
            if debut:
                qs = qs.filter(date__gte=debut)
            if fin:
                qs = qs.filter(date__lte=fin)
            for p in qs:
                journal = "CAI" if p.est_especes else "BQ"
                for l in ecritures_paiement(p):
                    E.append(_norm(l, "encaissement", p.facture.numero or "", journal, p.date))
            # Acomptes de location reçus, pas encore repris comme paiement d'une facture
            from facture.paiements import acomptes_locations_encaisses
            for p in acomptes_locations_encaisses(societe, debut=debut, fin=fin):
                journal = "CAI" if p.est_especes else "BQ"
                for l in ecritures_paiement(p):
                    E.append(_norm(l, "encaissement", p.piece, journal, p.date))
    except Exception:
        pass

    # ---- Ventes de véhicules de la flotte (facture VH…, encaissement ; la cession est passée par l'immobilisation)
    if sources & {"vente", "encaissement"}:
        try:
            from voiture.voiture_vente.models import VenteVehicule
            for v in (VenteVehicule.objects.filter(societe=societe).exclude(statut=VenteVehicule.Statut.BROUILLON)
                      .select_related("exemplaire", "compte_encaissement")):
                for l in v.ecritures():
                    if l["source"] in sources and _dans(l["date"], debut, fin):
                        E.append(_norm(l, l["source"], l["piece"]))
        except Exception:
            pass

    # ---- Achats (marchandises, outillage)
    if "achat" in sources:
        for chemin, nom in (("achat_mds.models", "AchatMds"), ("outillage.models", "Outillage")):
            try:
                from importlib import import_module
                modele = getattr(import_module(chemin), nom)
                for a in modele.objects.filter(societe=societe).select_related("fournisseur"):
                    for l in a.ecritures_comptables():
                        if _dans(l["date"], debut, fin):
                            E.append(_norm(l, "achat", a.reference_facture or ""))
            except Exception:
                pass

    # ---- Salaires et paiement des salaires
    if sources & {"salaire", "paiement_salaire"}:
        try:
            from utilisateurs.models import PaieUtilisateur
            for paie in PaieUtilisateur.objects.filter(utilisateur__societe=societe).select_related("utilisateur"):
                fin_mois = date(paie.annee, paie.mois, calendar.monthrange(paie.annee, paie.mois)[1])
                piece = f"PAIE-{paie.annee}{paie.mois:02d}-{paie.pk}"
                nom = f"{paie.utilisateur.prenom} {paie.utilisateur.nom}"
                for l in paie.ecritures_comptables(avec_paiement=True):
                    paiement = l.get("type") == "paiement"
                    source = "paiement_salaire" if paiement else "salaire"
                    jour = paie.date_paiement if paiement else fin_mois
                    if source in sources and _dans(jour, debut, fin):
                        l = dict(l, libelle=f"{l['libelle']} – {nom} {paie.mois:02d}/{paie.annee}")
                        E.append(_norm(l, source, piece, "BQ" if paiement else "OD", jour))
        except Exception:
            pass

    # ---- Paiements de congés / pécules hors paie mensuelle
    if sources & {"salaire", "paiement_salaire"}:
        try:
            from .models import PaiementConges
            for pc in PaiementConges.objects.filter(societe=societe).select_related("utilisateur", "compte_paiement"):
                for l in pc.ecritures(avec_paiement=True):
                    source = "paiement_salaire" if l["type"] == "paiement" else "salaire"
                    if source in sources and _dans(l["date"], debut, fin):
                        E.append(_norm(l, source, pc.piece))
        except Exception:
            pass

    # ---- Objets de la comptabilité
    from .models import FactureInstructeur, Immobilisation, MouvementTresorerie, ValorisationStock, VersementSocial
    if "versement_social" in sources:
        for v in VersementSocial.objects.filter(societe=societe):
            for l in v.ecritures():
                if _dans(l["date"], debut, fin):
                    E.append(_norm(l, "versement_social", v.reference))
    if "instructeur" in sources:
        for f in FactureInstructeur.objects.filter(societe=societe).exclude(statut=FactureInstructeur.Statut.BROUILLON).select_related("instructeur", "compte_paiement"):
            for l in f.ecritures():
                if _dans(l["date"], debut, fin):
                    E.append(_norm(l, "instructeur", f.piece))
    if "reversement" in sources:
        try:
            from voiture.voiture_location.models import ReversementLocation
            for r in ReversementLocation.objects.filter(location__societe=societe).select_related(
                    "location", "location__voiture_exemplaire"):
                for l in r.ecritures():
                    if _dans(l["date"], debut, fin):
                        E.append(_norm(l, "reversement", r.piece))
        except Exception:
            pass
    if "immobilisation" in sources:
        for i in Immobilisation.objects.filter(societe=societe).select_related("compte_paiement"):
            for l in i.ecritures(debut, fin):
                E.append(_norm(l, "immobilisation", i.reference_facture))
    if "financement" in sources:
        try:
            from voiture.voiture_exemplaire.financement import ecritures as ecritures_financement
            from voiture.voiture_exemplaire.models import FinancementVehicule
            for fv in FinancementVehicule.objects.filter(exemplaire__societe=societe).select_related(
                    "exemplaire", "compte_paiement"):
                for l in ecritures_financement(fv, debut, fin):
                    E.append(_norm(l, "financement", l["piece"]))
        except Exception:
            pass
    if "stock" in sources:
        for v in ValorisationStock.objects.filter(societe=societe):
            for l in v.ecritures():
                if _dans(l["date"], debut, fin):
                    E.append(_norm(l, "stock", f"INV-{v.date:%Y%m%d}"))
    if "tresorerie" in sources:
        qs = MouvementTresorerie.objects.filter(compte__societe=societe).select_related("compte")
        if debut:
            qs = qs.filter(date__gte=debut)
        if fin:
            qs = qs.filter(date__lte=fin)
        for m in qs:
            entree = m.sens == m.Sens.ENTREE
            journal = m.compte.journal_code
            base = {"libelle": m.libelle, "date": m.date}
            E.append(_norm(dict(base, compte=m.compte.compte_pcmn, intitule=m.compte.nom,
                                debit=m.montant if entree else ZERO, credit=ZERO if entree else m.montant),
                           "tresorerie", m.piece, journal))
            E.append(_norm(dict(base, compte=m.compte_contrepartie, intitule=m.intitule_contrepartie,
                                debit=ZERO if entree else m.montant, credit=m.montant if entree else ZERO),
                           "tresorerie", m.piece, journal))

    # ---- Soldes d'ouverture des caisses / banques
    if "ouverture" in sources:
        from .models import CompteTresorerie
        for c in CompteTresorerie.objects.filter(societe=societe):
            if c.solde_ouverture and _dans(c.date_ouverture, debut, fin):
                montant = Decimal(c.solde_ouverture)
                base = {"libelle": f"{_('Solde d’ouverture')} – {c.nom}", "date": c.date_ouverture}
                E.append(_norm(dict(base, compte=c.compte_pcmn, intitule=c.nom,
                                    debit=max(montant, ZERO), credit=max(-montant, ZERO)), "ouverture", "OUV", "OUV"))
                E.append(_norm(dict(base, compte=c.compte_contrepartie_ouverture or "499000", intitule="",
                                    debit=max(-montant, ZERO), credit=max(montant, ZERO)), "ouverture", "OUV", "OUV"))

    # ---- Opérations diverses
    if "od" in sources:
        from .models import OperationDiverse
        qs = OperationDiverse.objects.filter(societe=societe).prefetch_related("lignes")
        if debut:
            qs = qs.filter(date__gte=debut)
        if fin:
            qs = qs.filter(date__lte=fin)
        for od in qs:
            for l in od.ecritures():
                E.append(_norm(l, "od", l["piece"]))

    E.sort(key=lambda e: (e["date"], e["journal"], e["piece"], -e["debit"]))
    return E


def balance(ecritures):
    comptes = {}
    for e in ecritures:
        c = comptes.setdefault(e["compte"], {"compte": e["compte"], "intitule": e["intitule"], "debit": ZERO, "credit": ZERO})
        if not c["intitule"] and e["intitule"]:
            c["intitule"] = e["intitule"]
        c["debit"] += e["debit"]
        c["credit"] += e["credit"]
    lignes = sorted(comptes.values(), key=lambda c: c["compte"])
    for c in lignes:
        c["solde"] = c["debit"] - c["credit"]
        c["classe"] = c["compte"][:1]
    return lignes
