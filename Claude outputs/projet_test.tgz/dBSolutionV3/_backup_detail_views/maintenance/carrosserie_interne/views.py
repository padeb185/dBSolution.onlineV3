from django.core.exceptions import ValidationError

from django.template.loader import render_to_string
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import models, transaction
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _, gettext_noop
from django.views.decorators.cache import never_cache
from django.views.generic import ListView
from maindoeuvre.models import MainDoeuvre
from utilisateurs.models import UserLog
from weasyprint import HTML
from .forms import CarrosserieInterneForm
from .models import CarrosserieInterne
from voiture.voiture_exemplaire.models import VoitureExemplaire
from maintenance.models import Maintenance




@method_decorator([login_required, never_cache], name='dispatch')
class CarrosserieInterneListView(LoginRequiredMixin, ListView):
    model = CarrosserieInterne
    template_name = "carrosserie_interne/carrosserie_interne_list.html"
    context_object_name = "carrosserie_internes"
    ordering = ["-created_at"]

    def get_queryset(self):
        queryset = CarrosserieInterne.objects.select_related(
            "voiture_exemplaire",
            "societe",
            "tech_technicien",
            "tech_societe",
        )

        # 🔥 filtre par société
        societe = getattr(self.request.user, "societe", None)
        if societe:
            queryset = queryset.filter(
                models.Q(societe=societe) | models.Q(societe__isnull=True)
            )

        return queryset.order_by(*self.ordering)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        exemplaire_id = self.kwargs.get("exemplaire_id")

        if exemplaire_id:
            context["exemplaire"] = get_object_or_404(
                VoitureExemplaire,
                id=exemplaire_id
            )
        else:
            context["exemplaire"] = None

        context["is_checkup_allowed"] = self.request.user.role in [
            "direction",
            "mecanicien",
            "chef_mecanicien",
            "magasinier",
        ]

        context["sections"] = []

        return context

@never_cache
@login_required
def carrosserie_interne_create_view(request, exemplaire_id):

    tenant = request.user.societe
    role = request.user.role

    # ==========================================================
    # RÉCUPÉRATION DU VÉHICULE
    # ==========================================================

    exemplaire = get_object_or_404(
        VoitureExemplaire.objects.filter(
            Q(client__societe=tenant)
            | Q(
                client__isnull=True,
                societe=tenant,
            )
        ),
        id=exemplaire_id,
    )

    # ==========================================================
    # VÉRIFICATION DES RÔLES
    # ==========================================================

    roles_autorises = [
        "mecanicien",
        "apprenti",
        "magasinier",
        "chef_mecanicien",
        "direction",
    ]

    if (
        role not in roles_autorises
        and not request.user.is_superuser
    ):
        messages.error(
            request,
            _("Accès refusé"),
        )

        return redirect(
            "utilisateurs:dashboard"
        )

    # ==========================================================
    # MAINTENANCE
    # ==========================================================

    maintenance = None

    # ==========================================================
    # POST
    # ==========================================================

    if request.method == "POST":

        form = CarrosserieInterneForm(
            request.POST,
            user=request.user,
            exemplaire=exemplaire,
        )

        if form.is_valid():

            try:

                with transaction.atomic():

                    # ==================================================
                    # KILOMÉTRAGE AVANT INTERVENTION
                    # ==================================================

                    ancien_kilometrage = (
                        exemplaire.kilometres_chassis
                        or 0
                    )

                    ancien_kilometrage_boite = (
                        exemplaire.kilometres_boite
                        or 0
                    )

                    ancien_kilometrage_moteur = (
                        exemplaire.kilometres_moteur
                        or 0
                    )

                    ancien_kilometrage_embrayage = (
                        exemplaire.kilometres_embrayage
                        or 0
                    )

                    # ==================================================
                    # NOUVEAU KILOMÉTRAGE
                    # ==================================================

                    km = form.cleaned_data.get(
                        "kilometrage_intervention"
                    )

                    if km is None:
                        raise ValueError(
                            _(
                                "Le kilométrage de l'intervention "
                                "est obligatoire."
                            )
                        )

                    km = int(km)

                    if km < ancien_kilometrage:

                        raise ValueError(
                            _(
                                "Le kilométrage du contrôle carrosserie "
                                "ne peut pas être inférieur au kilométrage "
                                "actuel du véhicule."
                            )
                        )

                    kilometrage_variation = (
                        km
                        - ancien_kilometrage
                    )

                    # ==================================================
                    # PRÉPARATION CARROSSERIE INTERNE
                    # ==================================================

                    carrosserie_interne = (
                        form.save(
                            commit=False
                        )
                    )

                    carrosserie_interne.societe = (
                        tenant
                    )

                    carrosserie_interne.voiture_exemplaire = (
                        exemplaire
                    )

                    carrosserie_interne.immatriculation = (
                        exemplaire.immatriculation
                    )

                    # Kilométrage de l'intervention
                    carrosserie_interne.kilometrage_intervention = (
                        km
                    )

                    # Kilométrages AVANT intervention
                    carrosserie_interne.kilometres_chassis = (
                        ancien_kilometrage
                    )

                    carrosserie_interne.kilometres_boite = (
                        ancien_kilometrage_boite
                    )

                    carrosserie_interne.kilometres_moteur = (
                        ancien_kilometrage_moteur
                    )

                    carrosserie_interne.kilometres_embrayage = (
                        ancien_kilometrage_embrayage
                    )

                    carrosserie_interne.kilometrage_variation = (
                        kilometrage_variation
                    )

                    # ==================================================
                    # TECHNICIEN CARROSSERIE
                    # ==================================================

                    carrosserie_interne.assign_technicien(
                        request.user
                    )

                    carrosserie_interne.tech_last_maintained_by = (
                        request.user
                    )

                    # ==================================================
                    # ROLLBACK DU VÉHICULE
                    # ==================================================

                    exemplaire.kilometres_rollback = (
                        ancien_kilometrage
                    )

                    exemplaire.kilometres_boite_rollback = (
                        ancien_kilometrage_boite
                    )

                    exemplaire.kilometres_moteur_rollback = (
                        ancien_kilometrage_moteur
                    )

                    exemplaire.kilometres_embrayage_rollback = (
                        ancien_kilometrage_embrayage
                    )

                    # ==================================================
                    # DATE DERNIÈRE INTERVENTION
                    # ==================================================

                    exemplaire.date_derniere_intervention = (
                        timezone.localtime(
                            timezone.now()
                        ).date()
                    )

                    # ==================================================
                    # NOUVEAU KILOMÉTRAGE DU VÉHICULE
                    # ==================================================

                    exemplaire.kilometres_chassis = (
                        km
                    )

                    # Recalcule notamment :
                    # - kilometres_moteur
                    # - kilometres_boite
                    # - kilometres_embrayage
                    # - variation_kilometres

                    exemplaire.update_kilometres()

                    # ==================================================
                    # SAUVEGARDE DU VÉHICULE
                    # ==================================================

                    exemplaire.save(
                        update_fields=[
                            "kilometres_chassis",
                            "date_derniere_intervention",

                            # Rollback
                            "kilometres_rollback",
                            "kilometres_boite_rollback",
                            "kilometres_moteur_rollback",
                            "kilometres_embrayage_rollback",

                            # Valeurs recalculées
                            "kilometres_moteur",
                            "kilometres_boite",
                            "kilometres_embrayage",
                            "variation_kilometres",
                        ]
                    )

                    # ==================================================
                    # CRÉATION MAINTENANCE
                    # ==================================================

                    maintenance = (
                        Maintenance.objects.create(
                            societe=tenant,
                            voiture_exemplaire=exemplaire,
                            immatriculation=(
                                exemplaire.immatriculation
                            ),
                            date_intervention=(
                                timezone.now().date()
                            ),
                            kilometres_chassis=(
                                exemplaire.kilometres_chassis
                            ),
                            kilometres_dernier_entretien=(
                                exemplaire.kilometres_dernier_entretien
                            ),

                            # ⚠️ Vérifier que ce choix existe
                            type_maintenance=(
                                Maintenance.TypeMaintenance.CARROSSERIE_INTERNE
                            ),

                            tag=Maintenance.Tag.JAUNE,

                            # Utilisateur ayant réalisé
                            # la maintenance
                            tech_technicien=request.user,
                            tech_societe=tenant,
                            tech_nom_technicien=(
                                f"{request.user.prenom} "
                                f"{request.user.nom}"
                            ),
                            tech_role_technicien=(
                                request.user.role
                            ),
                        )
                    )

                    # ==================================================
                    # RÔLE DE L'UTILISATEUR
                    # ==================================================

                    if role == "mecanicien":

                        maintenance.mecanicien = (
                            request.user
                        )

                    elif role == "chef_mecanicien":

                        maintenance.chef_mecanicien = (
                            request.user
                        )

                    elif role == "apprenti":

                        maintenance.apprentis = (
                            request.user
                        )

                    maintenance.save()

                    # ==================================================
                    # LIEN CARROSSERIE -> MAINTENANCE
                    # ==================================================

                    carrosserie_interne.maintenance = (
                        maintenance
                    )

                    # ==================================================
                    # MAIN-D'ŒUVRE
                    # ==================================================

                    heures = (
                        form.cleaned_data.get(
                            "temps_heures"
                        )
                        or 0
                    )

                    minutes = (
                        form.cleaned_data.get(
                            "temps_minutes"
                        )
                        or 0
                    )

                    total_minutes = (
                        heures * 60
                        + minutes
                    )

                    taux_horaire = (
                        form.cleaned_data.get(
                            "taux_horaire"
                        )
                        or 0
                    )

                    # ==================================================
                    # MAIN-D'ŒUVRE EXISTANTE
                    # ==================================================

                    if carrosserie_interne.main_oeuvre_id:

                        main_oeuvre = (
                            carrosserie_interne.main_oeuvre
                        )

                        main_oeuvre.temps_minutes = (
                            total_minutes
                        )

                        main_oeuvre.taux_horaire = (
                            taux_horaire
                        )

                        main_oeuvre.save(
                            update_fields=[
                                "temps_minutes",
                                "taux_horaire",
                            ]
                        )

                    # ==================================================
                    # NOUVELLE MAIN-D'ŒUVRE
                    # ==================================================

                    else:

                        main_oeuvre = (
                            MainDoeuvre.objects.create(
                                utilisateur=request.user,
                                temps_minutes=(
                                    total_minutes
                                ),
                                taux_horaire=(
                                    taux_horaire
                                ),
                            )
                        )

                        carrosserie_interne.main_oeuvre = (
                            main_oeuvre
                        )

                    # ==================================================
                    # SAUVEGARDE CARROSSERIE INTERNE
                    # ==================================================

                    carrosserie_interne.save()

                    # Champs ManyToMany éventuels
                    form.save_m2m()

                    # ==================================================
                    # USER LOG
                    # ==================================================

                    ACTION_CARROSSERIE = (
                        gettext_noop(
                            "Carrosserie"
                        )
                    )

                    UserLog.objects.create(
                        utilisateur=request.user,
                        action=(
                            f"{ACTION_CARROSSERIE} - "
                            f"{exemplaire.immatriculation}"
                        ),
                    )

                # ======================================================
                # SUCCÈS
                # ======================================================

                messages.success(
                    request,
                    _(
                        "Intervention carrosserie "
                        "enregistrée avec succès."
                    ),
                )

                return redirect(
                    f"{reverse('carrosserie_interne:carrosserie_interne_list',kwargs={'exemplaire_id': exemplaire.id})}?saved=1"
                )

            except Exception as e:

                messages.error(
                    request,
                    _("Erreur : %(erreur)s") % {
                        "erreur": str(e)
                    },
                )

        else:

            messages.error(
                request,
                _(
                    "Le formulaire contient "
                    "des erreurs."
                ),
            )

    # ==========================================================
    # GET
    # ==========================================================

    else:

        carrosserie_interne = (
            CarrosserieInterne(
                societe=tenant,
                voiture_exemplaire=exemplaire,

                kilometres_chassis=(
                    exemplaire.kilometres_chassis
                    or 0
                ),

                kilometres_moteur=(
                    exemplaire.kilometres_moteur
                    or 0
                ),

                kilometres_boite=(
                    exemplaire.kilometres_boite
                    or 0
                ),

                kilometres_embrayage=(
                    exemplaire.kilometres_embrayage
                    or 0
                ),
            )
        )

        carrosserie_interne.assign_technicien(
            request.user
        )

        form = CarrosserieInterneForm(
            instance=carrosserie_interne,
            user=request.user,
            exemplaire=exemplaire,
        )

    # ==========================================================
    # SECTIONS
    # ==========================================================

    sections = [
        {
            "title": _("Kilométrage"),
            "icon": "icons/compteur.png",
            "fields": [
                f for f in form
                if "kilo" in f.name
            ],
        },
        {
            "title": _("Pare-chocs avant"),
            "icon": "icons/pare-chocs.png",
            "fields": [
                f for f in form
                if "pare_choc_av" in f.name
            ],
        },
        {
            "title": _("Pare-chocs arrière"),
            "icon": "icons/pare-chocs.png",
            "fields": [
                f for f in form
                if "pare_choc_ar" in f.name
            ],
        },
        {
            "title": _("Traverse avant"),
            "icon": "icons/pare-chocs.png",
            "fields": [
                f for f in form
                if "bouclier_av" in f.name
            ],
        },
        {
            "title": _("Traverse arrière"),
            "icon": "icons/pare-chocs.png",
            "fields": [
                f for f in form
                if "bouclier_ar" in f.name
            ],
        },
        {
            "title": _("Support de pare-chocs avant"),
            "icon": "icons/pare-chocs.png",
            "fields": [
                f for f in form
                if "support_pa_choc_av" in f.name
            ],
        },
        {
            "title": _("Support de pare-chocs arrière"),
            "icon": "icons/pare-chocs.png",
            "fields": [
                f for f in form
                if "support_pa_choc_ar" in f.name
            ],
        },
        {
            "title": _("Calandre"),
            "icon": "icons/calandre.png",
            "fields": [
                f for f in form
                if "calandre" in f.name
            ],
        },
        {
            "title": _("Aile avant droite"),
            "icon": "icons/aile.png",
            "fields": [
                f for f in form
                if "aile_avd" in f.name
            ],
        },
        {
            "title": _("Aile avant gauche"),
            "icon": "icons/aile.png",
            "fields": [
                f for f in form
                if "aile_avg" in f.name
            ],
        },
        {
            "title": _("Aile arrière droite"),
            "icon": "icons/aile_ar.png",
            "fields": [
                f for f in form
                if "aile_ard" in f.name
            ],
        },
        {
            "title": _("Aile arrière gauche"),
            "icon": "icons/aile_ar.png",
            "fields": [
                f for f in form
                if "aile_arg" in f.name
            ],
        },
        {
            "title": _(
                "Élargisseur d'aile avant droite"
            ),
            "icon": "icons/elargisseur.png",
            "fields": [
                f for f in form
                if "elargisseur_ail_avd" in f.name
            ],
        },
        {
            "title": _(
                "Élargisseur d'aile avant gauche"
            ),
            "icon": "icons/elargisseur.png",
            "fields": [
                f for f in form
                if "elargisseur_ail_avg" in f.name
            ],
        },
        {
            "title": _(
                "Élargisseur d'aile arrière droite"
            ),
            "icon": "icons/elargisseur.png",
            "fields": [
                f for f in form
                if "elargisseur_ail_ard" in f.name
            ],
        },
        {
            "title": _(
                "Élargisseur d'aile arrière gauche"
            ),
            "icon": "icons/elargisseur.png",
            "fields": [
                f for f in form
                if "elargisseur_ail_arg" in f.name
            ],
        },
        {
            "title": _("Bas de caisse droit"),
            "icon": "icons/bas-de-caisse.png",
            "fields": [
                f for f in form
                if "bas_de_caisse_d" in f.name
            ],
        },
        {
            "title": _("Bas de caisse gauche"),
            "icon": "icons/bas-de-caisse.png",
            "fields": [
                f for f in form
                if "bas_de_caisse_g" in f.name
            ],
        },
        {
            "title": _("Porte avant droite"),
            "icon": "icons/porte-de-voiture.png",
            "fields": [
                f for f in form
                if "porte_avd_po" in f.name
            ],
        },
        {
            "title": _("Porte avant gauche"),
            "icon": "icons/porte-de-voiture.png",
            "fields": [
                f for f in form
                if "porte_avg_po" in f.name
            ],
        },
        {
            "title": _("Porte arrière droite"),
            "icon": "icons/porte-de-voiture.png",
            "fields": [
                f for f in form
                if "porte_ard_po" in f.name
            ],
        },
        {
            "title": _("Porte arrière gauche"),
            "icon": "icons/porte-de-voiture.png",
            "fields": [
                f for f in form
                if "porte_arg_po" in f.name
            ],
        },
        {
            "title": _("Poignée de porte"),
            "icon": "icons/porte-de-voiture.png",
            "fields": [
                f for f in form
                if "poignee_porte" in f.name
            ],
        },
        {
            "title": _("Coffre"),
            "icon": "icons/coffre.png",
            "fields": [
                f for f in form
                if "coffre_hai" in f.name
            ],
        },
        {
            "title": _("Capot"),
            "icon": "icons/capot.png",
            "fields": [
                f for f in form
                if "capot_pi" in f.name
            ],
        },
        {
            "title": _("Joint de coffre"),
            "icon": "icons/joint-coffre.png",
            "fields": [
                f for f in form
                if "joint_coffre" in f.name
            ],
        },
        {
            "title": _("Joint de porte avant droite"),
            "icon": "icons/joint-porte.png",
            "fields": [
                f for f in form
                if "joint_porte_avd" in f.name
            ],
        },
        {
            "title": _("Joint de porte avant gauche"),
            "icon": "icons/joint-porte.png",
            "fields": [
                f for f in form
                if "joint_porte_avg" in f.name
            ],
        },
        {
            "title": _("Joint de porte arrière droite"),
            "icon": "icons/joint-porte.png",
            "fields": [
                f for f in form
                if "joint_porte_ard" in f.name
            ],
        },
        {
            "title": _("Joint de porte arrière gauche"),
            "icon": "icons/joint-porte.png",
            "fields": [
                f for f in form
                if "joint_porte_arg" in f.name
            ],
        },
        {
            "title": _(
                "Coquille d'aile avant droite"
            ),
            "icon": "icons/aile.png",
            "fields": [
                f for f in form
                if "coquille_ai_avd" in f.name
            ],
        },
        {
            "title": _(
                "Coquille d'aile avant gauche"
            ),
            "icon": "icons/aile.png",
            "fields": [
                f for f in form
                if "coquille_ai_avg" in f.name
            ],
        },
        {
            "title": _(
                "Coquille d'aile arrière droite"
            ),
            "icon": "icons/aile.png",
            "fields": [
                f for f in form
                if "coquille_ai_ard" in f.name
            ],
        },
        {
            "title": _(
                "Coquille d'aile arrière gauche"
            ),
            "icon": "icons/aile.png",
            "fields": [
                f for f in form
                if "coquille_ai_arg" in f.name
            ],
        },
        {
            "title": _("Support de radiateur"),
            "icon": "icons/radiateur.png",
            "fields": [
                f for f in form
                if "support_radiateur" in f.name
            ],
        },
        {
            "title": _("Pare-brise"),
            "icon": "icons/pare-brise-casse.png",
            "fields": [
                f for f in form
                if "pa_brise" in f.name
            ],
        },
        {
            "title": _("Vitre de porte avant droite"),
            "icon": "icons/vitre.png",
            "fields": [
                f for f in form
                if "vitre_porte_avd" in f.name
            ],
        },
        {
            "title": _("Vitre de porte avant gauche"),
            "icon": "icons/vitre.png",
            "fields": [
                f for f in form
                if "vitre_porte_avg" in f.name
            ],
        },
        {
            "title": _("Vitre de porte arrière droite"),
            "icon": "icons/vitre.png",
            "fields": [
                f for f in form
                if "vitre_porte_ard" in f.name
            ],
        },
        {
            "title": _("Vitre de porte arrière gauche"),
            "icon": "icons/vitre.png",
            "fields": [
                f for f in form
                if "vitre_porte_arg" in f.name
            ],
        },
        {
            "title": _("Lunette / vitre arrière"),
            "icon": "icons/lunette.png",
            "fields": [
                f for f in form
                if "lunette" in f.name
            ],
        },
        {
            "title": _("Rétroviseur droit"),
            "icon": "icons/retro.png",
            "fields": [
                f for f in form
                if "retroviseur_d" in f.name
            ],
        },
        {
            "title": _("Rétroviseur gauche"),
            "icon": "icons/retro.png",
            "fields": [
                f for f in form
                if "retroviseur_g" in f.name
            ],
        },
        {
            "title": _("Phare avant droit"),
            "icon": "icons/phares.png",
            "fields": [
                f for f in form
                if "phare_avd" in f.name
            ],
        },
        {
            "title": _("Phare avant gauche"),
            "icon": "icons/phares.png",
            "fields": [
                f for f in form
                if "phare_avg" in f.name
            ],
        },
        {
            "title": _("Feu arrière droit"),
            "icon": "icons/phares.png",
            "fields": [
                f for f in form
                if "phare_ard" in f.name
            ],
        },
        {
            "title": _("Feu arrière gauche"),
            "icon": "icons/phares.png",
            "fields": [
                f for f in form
                if "phare_arg" in f.name
            ],
        },
        {
            "title": _(
                "Anti-brouillard avant droit"
            ),
            "icon": "icons/phares.png",
            "fields": [
                f for f in form
                if "anti_brouillard_avd" in f.name
            ],
        },
        {
            "title": _(
                "Anti-brouillard avant gauche"
            ),
            "icon": "icons/phares.png",
            "fields": [
                f for f in form
                if "anti_brouillard_avg" in f.name
            ],
        },
        {
            "title": _("Anti-brouillard arrière"),
            "icon": "icons/phares.png",
            "fields": [
                f for f in form
                if "anti_brouillard_ar" in f.name
            ],
        },
        {
            "title": _("Clignotant avant droit"),
            "icon": "icons/clignotant.png",
            "fields": [
                f for f in form
                if "clignotant_avd" in f.name
            ],
        },
        {
            "title": _("Clignotant avant gauche"),
            "icon": "icons/clignotant.png",
            "fields": [
                f for f in form
                if "clignotant_avg" in f.name
            ],
        },
        {
            "title": _("Clignotant arrière droit"),
            "icon": "icons/clignotant.png",
            "fields": [
                f for f in form
                if "clignotant_ard" in f.name
            ],
        },
        {
            "title": _("Clignotant arrière gauche"),
            "icon": "icons/clignotant.png",
            "fields": [
                f for f in form
                if "clignotant_arg" in f.name
            ],
        },
        {
            "title": _("Troisième feu stop"),
            "icon": "icons/feu-stop.png",
            "fields": [
                f for f in form
                if "troisieme_feu_stop" in f.name
            ],
        },
        {
            "title": _("Capteur de recul"),
            "icon": "icons/capteurs.png",
            "fields": [
                f for f in form
                if "capteur_recul" in f.name
            ],
        },
        {
            "title": _("Clips"),
            "icon": "icons/clips.png",
            "fields": [
                f for f in form
                if "clips" in f.name
            ],
        },
        {
            "title": _("Visserie"),
            "icon": "icons/visserie.png",
            "fields": [
                f for f in form
                if "visserie" in f.name
            ],
        },
        {
            "title": _("Peinture de l'aile avant droite"),
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [
                f for f in form
                if "peinture_avant_droit" in f.name
            ],
        },
        {
            "title": _("Peinture de l'aile avant gauche"),
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [
                f for f in form
                if "peinture_avant_gauche" in f.name
            ],
        },
        {
            "title": _("Peinture de l'aile arrière droite"),
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [
                f for f in form
                if "peinture_arriere_droit" in f.name
            ],
        },
        {
            "title": _("Peinture de l'aile arrière gauche"),
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [
                f for f in form
                if "peinture_arriere_gauche" in f.name
            ],
        },
        {
            "title": _("Peinture de la face avant"),
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [
                f for f in form
                if "peinture_face_avant" in f.name
            ],
        },
        {
            "title": _("Peinture du capot"),
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [
                f for f in form
                if "peinture_capot" in f.name
            ],
        },
        {
            "title": _("Peinture arrière complete"),
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [
                f for f in form
                if "peinture_arriere_complete" in f.name
            ],
        },
        {
            "title": _("Peinture complète"),
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [
                f for f in form
                if "peinture_complete" in f.name
            ],
        },
        {
            "title": _("Pays"),
            "icon": "icons/pays.png",
            "fields": [
                f for f in form
                if "pays" in f.name
            ],
        },
        {
            "title": _("Etiquette"),
            "icon": "icons/tag.png",
            "fields": [
                f for f in form
                if "tag" in f.name
            ],
        },
        {
            "title": _("Serrage des roues"),
            "icon": "icons/roue.png",
            "fields": [
                f for f in form
                if "serrage" in f.name
            ],
        },
        {
            "title": _("Remarques"),
            "icon": "icons/notes.png",
            "fields": [
                f for f in form
                if "remarques" in f.name
            ],
        },
        {
            "title": _("Technicien"),
            "icon": "icons/mecanicien.png",
            "fields": [
                f for f in form
                if "tech" in f.name
            ],
        },
        {
            "title": _("Taux horaire"),
            "icon": "icons/taux.png",
            "fields": [
                f for f in form
                if "taux" in f.name
            ],
        },
    ]

    # ==========================================================
    # RENDER
    # ==========================================================

    return render(
        request,
        "carrosserie_interne/carrosserie_interne_create.html",
        {
            "exemplaire": exemplaire,
            "maintenance": maintenance,
            "form": form,
            "sections": sections,
            "now": timezone.now(),
        },
    )

# ------------
# Vue détail carrosserie_interne
# -----------------------------
@never_cache
@login_required
def carrosserie_interne_detail_view(request, carrosserie_interne_id):
    carrosserie_interne = get_object_or_404(
       CarrosserieInterne.objects.select_related("voiture_exemplaire"),
        id=carrosserie_interne_id
    )

    context = {
        "carrosserie_interne": carrosserie_interne,
        "exemplaire": carrosserie_interne.voiture_exemplaire,
    }
    return render(request, "carrosserie_interne/carrosserie_interne_detail.html", context)






@login_required
def modifier_carrosserie_interne_view(request, carrosserie_interne_id):
    tenant = request.user.societe


    # Récupération de l'objet CarrosserieInterne avec son exemplaire
    carrosserie_interne = get_object_or_404(
        CarrosserieInterne.objects.select_related("voiture_exemplaire"),
        id=carrosserie_interne_id
    )

    exemplaire = carrosserie_interne.voiture_exemplaire

    # -------------------------
    # Gestion POST
    # -------------------------
    if request.method == "POST":
        form = CarrosserieInterneForm(
            request.POST,
            instance=carrosserie_interne,
            user=request.user,
            exemplaire=carrosserie_interne.voiture_exemplaire
        )
        if form.is_valid():

            try:
                with transaction.atomic():

                    # ==================================================
                    # NOUVEAU KILOMÉTRAGE SAISI
                    # ==================================================
                    km = form.cleaned_data.get(
                        "kilometrage_intervention"
                    )

                    if km is not None:
                        km = int(km)

                    # ==================================================
                    # VALEURS ACTUELLES = ROLLBACK LOCAL
                    # ==================================================
                    rollback_chassis = (
                            exemplaire.kilometres_chassis or 0
                    )

                    rollback_moteur = (
                            exemplaire.kilometres_moteur or 0
                    )

                    rollback_boite = (
                            exemplaire.kilometres_boite or 0
                    )

                    rollback_embrayage = (
                            exemplaire.kilometres_embrayage or 0
                    )

                    # ==================================================
                    # VALIDATION
                    # ==================================================
                    if km is not None:

                        if km < 0:
                            raise ValidationError(
                                _(
                                    "Le kilométrage ne peut pas "
                                    "être négatif."
                                )
                            )

                        if km < rollback_chassis:
                            raise ValidationError(
                                _(
                                    "Le kilométrage ne peut pas être "
                                    "inférieur à %(km)s km."
                                ) % {
                                    "km": rollback_chassis
                                }
                            )

                    # ==================================================
                    # ÉCHAPPEMENT
                    # ==================================================
                    carrosserie_interne = form.save(
                        commit=False
                    )

                    carrosserie_interne.voiture_exemplaire = (
                        exemplaire
                    )

                    # ==================================================
                    # ROLLBACK LOCAL
                    # ==================================================
                    carrosserie_interne.kilometres_chassis = (
                        rollback_chassis
                    )

                    carrosserie_interne.kilometres_moteur = (
                        rollback_moteur
                    )

                    carrosserie_interne.kilometres_boite = (
                        rollback_boite
                    )

                    carrosserie_interne.kilometres_embrayage = (
                        rollback_embrayage
                    )

                    # ==================================================
                    # NOUVEAU KILOMÉTRAGE
                    # ==================================================
                    carrosserie_interne.kilometrage_alte = km

                    # ==================================================
                    # VARIATION
                    # ==================================================
                    if km is not None:
                        carrosserie_interne.kilometrage_variation = (
                                km - rollback_chassis
                        )
                    else:
                        carrosserie_interne.kilometrage_variation = 0

                    # ==================================================
                    # TECHNICIEN
                    # ==================================================
                    carrosserie_interne.assign_technicien(
                        request.user
                    )

                    carrosserie_interne.tech_last_maintained_by = (
                        request.user
                    )

                    # ==================================================
                    # MISE À JOUR DU VÉHICULE
                    # ==================================================
                    if km is not None:
                        exemplaire.kilometres_chassis = km

                        exemplaire.date_derniere_intervention = (
                            timezone.localtime(
                                timezone.now()
                            ).date()
                        )

                        exemplaire.save()

                    # ==================================================
                    # SAUVEGARDE ÉCHAPPEMENT
                    # ==================================================
                    carrosserie_interne.save()

                    form.save_m2m()



                ACTION_MODIFICATION_CARROSSERIE = gettext_noop(
                    "Modification de la carrosserie"
                )

                UserLog.objects.create(
                    utilisateur=request.user,
                    action=f"{ACTION_MODIFICATION_CARROSSERIE} - {exemplaire.immatriculation}"
                )

                messages.success(request, _("Carrosserie modifiée avec succès !"))

                return redirect(
                    f"{reverse('carrosserie_interne:carrosserie_interne_detail', kwargs={'carrosserie_interne_id': carrosserie_interne.id})}?saved=1"
                )

            except ValidationError as e:
                form.add_error(None, e)
                messages.error(request, _("Kilométrage invalide"))


        else:
            messages.error(request, _("Le formulaire contient des erreurs."))
            print(form.errors)

    # -------------------------
    # Gestion GET
    # -------------------------
    else:
        form = CarrosserieInterneForm(
            instance=carrosserie_interne,
            user=request.user,
            exemplaire=carrosserie_interne.voiture_exemplaire
        )

    # -------------------------
    # Organisation des champs par sections pour le template
    # -------------------------
    sections = [
        {
            "title": "Kilométrage",
            "icon": "icons/compteur.png",
            "fields": [f for f in form if "kilo" in f.name],
        },
        {
            "title": "Pare-chocs avant",
            "icon": "icons/pare-chocs.png",
            "fields": [f for f in form if "pare_choc_av" in f.name],
        },
        {
            "title": "Pare-chocs arrière",
            "icon": "icons/pare-chocs.png",
            "fields": [f for f in form if "pare_choc_ar" in f.name],
        },
        {
            "title": "Traverse avant",
            "icon": "icons/pare-chocs.png",
            "fields": [f for f in form if "bouclier_av" in f.name],
        },
        {
            "title": "Traverse arrière",
            "icon": "icons/pare-chocs.png",
            "fields": [f for f in form if "bouclier_ar" in f.name],
        },

        {
            "title": "Support pare-chocs avant",
            "icon": "icons/pare-chocs.png",
            "fields": [f for f in form if "support_pa_choc_av" in f.name],
        },
        {
            "title": "Support pare-chocs arrière",
            "icon": "icons/pare-chocs.png",
            "fields": [f for f in form if "support_pa_choc_ar" in f.name],
        },

        {
            "title": "Calandre",
            "icon": "icons/calandre.png",
            "fields": [f for f in form if "calandre" in f.name],
        },
        {
            "title": "Aile avant droite",
            "icon": "icons/aile.png",
            "fields": [f for f in form if "aile_avd" in f.name],
        },

        {
            "title": "Aile avant gauche",
            "icon": "icons/aile.png",
            "fields": [f for f in form if "aile_avg" in f.name],
        },
        {
            "title": "Aile arrière droite",
            "icon": "icons/aile_ar.png",
            "fields": [f for f in form if "aile_ard" in f.name],
        },

        {
            "title": "Aile arrière gauche",
            "icon": "icons/aile_ar.png",
            "fields": [f for f in form if "aile_arg" in f.name],
        },

        {
            "title": "Élargisseur d'aile avant droite",
            "icon": "icons/elargisseur.png",
            "fields": [f for f in form if "elargisseur_ail_avd" in f.name],
        },
        {
            "title": "Élargisseur d'aile avant gauche",
            "icon": "icons/elargisseur.png",
            "fields": [f for f in form if "elargisseur_ail_avg" in f.name],
        },
        {
            "title": "Élargisseur d'aile arrière droite",
            "icon": "icons/elargisseur.png",
            "fields": [f for f in form if "elargisseur_ail_ard" in f.name],
        },
        {
            "title": "Élargisseur d'aile arrière gauche",
            "icon": "icons/elargisseur.png",
            "fields": [f for f in form if "elargisseur_ail_arg" in f.name],
        },

        {
            "title": "Bas de caisse droit",
            "icon": "icons/bas-de-caisse.png",
            "fields": [f for f in form if "bas_de_caisse_d" in f.name],
        },
        {
            "title": "Bas de caisse gauche",
            "icon": "icons/bas-de-caisse.png",
            "fields": [f for f in form if "bas_de_caisse_g" in f.name],
        },
        {
            "title": "Porte avant droite",
            "icon": "icons/porte-de-voiture.png",
            "fields": [f for f in form if "porte_avd_po" in f.name],
        },
        {
            "title": "Porte avant gauche",
            "icon": "icons/porte-de-voiture.png",
            "fields": [f for f in form if "porte_avg_po" in f.name],
        },
        {
            "title": "Porte arrière droite",
            "icon": "icons/porte-de-voiture.png",
            "fields": [f for f in form if "porte_ard_po" in f.name],
        },
        {
            "title": "Porte arrière gauche",
            "icon": "icons/porte-de-voiture.png",
            "fields": [f for f in form if "porte_arg_po" in f.name],
        },
        {
            "title": "Poignée de porte",
            "icon": "icons/porte-de-voiture.png",
            "fields": [f for f in form if "poignee_porte" in f.name],
        },

        {
            "title": "Coffre",
            "icon": "icons/coffre.png",
            "fields": [f for f in form if "coffre_hai" in f.name],
        },

        {
            "title": "Capot",
            "icon": "icons/capot.png",
            "fields": [f for f in form if "capot_pi" in f.name],
        },

        {
            "title": "Joint de coffre",
            "icon": "icons/joint-coffre.png",
            "fields": [f for f in form if "joint_coffre" in f.name],
        },
        {
            "title": "Joint de porte avant droite",
            "icon": "icons/joint-porte.png",
            "fields": [f for f in form if "joint_porte_avd" in f.name],
        },
        {
            "title": "Joint de porte avant gauche",
            "icon": "icons/joint-porte.png",
            "fields": [f for f in form if "joint_porte_avg" in f.name],
        },
        {
            "title": "Joint de porte arrière droite",
            "icon": "icons/joint-porte.png",
            "fields": [f for f in form if "joint_porte_ard" in f.name],
        },
        {
            "title": "Joint de porte arrière gauche",
            "icon": "icons/joint-porte.png",
            "fields": [f for f in form if "joint_porte_arg" in f.name],
        },
        {
            "title": "Coquille d'aile avant droite",
            "icon": "icons/aile.png",
            "fields": [f for f in form if "coquille_ai_avd" in f.name],
        },
        {
            "title": "Coquille d'aile avant gauche",
            "icon": "icons/aile.png",
            "fields": [f for f in form if "coquille_ai_avg" in f.name],
        },
        {
            "title": "Coquille d'aile arrière droite",
            "icon": "icons/aile.png",
            "fields": [f for f in form if "coquille_ai_ard" in f.name],
        },
        {
            "title": "Coquille d'aile arrière gauche",
            "icon": "icons/aile.png",
            "fields": [f for f in form if "coquille_ai_arg" in f.name],
        },

        {
            "title": "Support de radiateur",
            "icon": "icons/radiateur.png",
            "fields": [f for f in form if "support_radiateur" in f.name],
        },

        # Pare-brise
        {
            "title": "Pare-brise",
            "icon": "icons/pare-brise-casse.png",
            "fields": [f for f in form if "pa_brise" in f.name],
        },

        # Vitres de portes
        {
            "title": "Vitre de porte avant droite",
            "icon": "icons/vitre.png",
            "fields": [f for f in form if "vitre_porte_avd" in f.name],
        },
        {
            "title": "Vitre de porte avant gauche",
            "icon": "icons/vitre.png",
            "fields": [f for f in form if "vitre_porte_avg" in f.name],
        },
        {
            "title": "Vitre de porte arrière droite",
            "icon": "icons/vitre.png",
            "fields": [f for f in form if "vitre_porte_ard" in f.name],
        },
        {
            "title": "Vitre de porte arrière gauche",
            "icon": "icons/vitre.png",
            "fields": [f for f in form if "vitre_porte_arg" in f.name],
        },

        # Lunette arrière
        {
            "title": "Lunette / vitre arrière",
            "icon": "icons/lunette.png",
            "fields": [f for f in form if "lunette" in f.name],
        },

        # Rétroviseurs
        {
            "title": "Rétroviseur droit",
            "icon": "icons/retro.png",
            "fields": [f for f in form if "retroviseur_d" in f.name],
        },
        {
            "title": "Rétroviseur gauche",
            "icon": "icons/retro.png",
            "fields": [f for f in form if "retroviseur_g" in f.name],
        },

        # Phares
        {
            "title": "Phare avant droit",
            "icon": "icons/phares.png",
            "fields": [f for f in form if "phare_avd" in f.name],
        },
        {
            "title": "Phare avant gauche",
            "icon": "icons/phares.png",
            "fields": [f for f in form if "phare_avg" in f.name],
        },
        {
            "title": "Feu arrière droit",
            "icon": "icons/phares.png",
            "fields": [f for f in form if "phare_ard" in f.name],
        },
        {
            "title": "Feu arrière gauche",
            "icon": "icons/phares.png",
            "fields": [f for f in form if "phare_arg" in f.name],
        },
        # Anti-brouillards
        {
            "title": "Anti-brouillard avant droit",
            "icon": "icons/phares.png",
            "fields": [f for f in form if "anti_brouillard_avd" in f.name],
        },
        {
            "title": "Anti-brouillard avant gauche",
            "icon": "icons/phares.png",
            "fields": [f for f in form if "anti_brouillard_avg" in f.name],
        },
        {
            "title": "Anti-brouillard arrière",
            "icon": "icons/phares.png",
            "fields": [f for f in form if "anti_brouillard_ar" in f.name],
        },

        {
            "title": "Clignotant avant droit",
            "icon": "icons/clignotant.png",
            "fields": [f for f in form if "clignotant_avd" in f.name],
        },
        {
            "title": "Clignotant avant gauche",
            "icon": "icons/clignotant.png",
            "fields": [f for f in form if "clignotant_avg" in f.name],
        },
        {
            "title": "Clignotant arrière droit",
            "icon": "icons/clignotant.png",
            "fields": [f for f in form if "clignotant_ard" in f.name],
        },
        {
            "title": "Clignotant arrière gauche",
            "icon": "icons/clignotant.png",
            "fields": [f for f in form if "clignotant_arg" in f.name],
        },

        # Troisième feu stop
        {
            "title": "Troisième feu stop",
            "icon": "icons/feu-stop.png",
            "fields": [f for f in form if "troisieme_feu_stop" in f.name],
        },

        # Capteur de recul
        {
            "title": "Capteur de recul",
            "icon": "icons/capteurs.png",
            "fields": [f for f in form if "capteur_recul" in f.name],
        },

        # Clips et visserie
        {
            "title": "Clips",
            "icon": "icons/clips.png",
            "fields": [f for f in form if "clips" in f.name],
        },

        {
            "title": "Visserie",
            "icon": "icons/visserie.png",
            "fields": [f for f in form if "visserie" in f.name],
        },

        {
            "title": "Peinture aile avant droite",
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [f for f in form if "peinture_avant_droit" in f.name],
        },
        {
            "title": "Peinture aile avant gauche",
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [f for f in form if "peinture_avant_gauche" in f.name],
        },
        # Aile arrière droite
        {
            "title": "Peinture aile arrière droite",
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [f for f in form if "peinture_arriere_droit" in f.name],
        },

        # Aile arrière gauche
        {
            "title": "Peinture aile arrière gauche",
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [f for f in form if "peinture_arriere_gauche" in f.name],
        },

        # Face avant
        {
            "title": "Peinture face avant",
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [f for f in form if "peinture_face_avant" in f.name],
        },

        # Capot
        {
            "title": "Peinture capot",
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [f for f in form if "peinture_capot" in f.name],
        },

        # Arrière complet
        {
            "title": "Peinture arrière complete",
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [f for f in form if "peinture_arriere_complete" in f.name],
        },

        # Peinture complète
        {
            "title": "Peinture complète",
            "icon": "icons/pistolet-a-peinture.png",
            "fields": [f for f in form if "peinture_complete" in f.name],
        },

        {
            "title": "Pays",
            "icon": "icons/pays.png",
            "fields": [f for f in form if "pays" in f.name],
        },

        {
            "title": "Etiquette",
            "icon": "icons/tag.png",
            "fields": [f for f in form if "tag" in f.name],
        },
        {
            "title": _("Serrage des roues"),
            "icon": "icons/roue.png",
            "fields": [form[f.name] for f in form if "serrage" in f.name],
        },
        {
            "title": "Remarques",
            "icon": "icons/notes.png",
            "fields": [f for f in form if "remarques" in f.name],
        },
        {
            "title": "Technicien",
            "icon": "icons/mecanicien.png",
            "fields": [f for f in form if "tech" in f.name],
        },
        {
            "title": "Taux horaire",
            "icon": "icons/taux.png",
            "fields": [f for f in form if "taux" in f.name],
        },
    ]

    return render(
        request,
        "carrosserie_interne/modifier_carrosserie_interne.html",
        {
            "form": form,
            "carrosserie_interne": carrosserie_interne,
            "exemplaire": exemplaire,
            "sections": sections,
        }
    )



@never_cache
@login_required
def delete_carrosserie_interne_view(request, carrosserie_interne_id):

    tenant = request.user.societe
    role = request.user.role

    # ==================================================
    # AUTORISATIONS
    # ==================================================
    roles_autorises = [
        "direction",
        "chef_mecanicien",
    ]

    if (
        role not in roles_autorises
        and not request.user.is_superuser
    ):
        messages.error(
            request,
            _("Accès refusé")
        )
        return redirect(
            "utilisateurs:dashboard"
        )

    # ==================================================
    # RÉCUPÉRATION CHECKUP
    # ==================================================
    carrosserie_interne = get_object_or_404(
        CarrosserieInterne.objects.select_related(
            "voiture_exemplaire",
            "maintenance",
        ),
        id=carrosserie_interne_id,
    )

    exemplaire = carrosserie_interne.voiture_exemplaire
    maintenance = carrosserie_interne.maintenance

    # ==================================================
    # VÉRIFICATION TENANT
    # ==================================================
    if not (
        (
            exemplaire.client
            and exemplaire.client.societe == tenant
        )
        or
        (
            exemplaire.client is None
            and exemplaire.societe == tenant
        )
    ):
        messages.error(
            request,
            _("Accès refusé")
        )
        return redirect(
            "utilisateurs:dashboard"
        )

    # ==================================================
    # DELETE
    # ==================================================
    if request.method == "POST":

        try:
            with transaction.atomic():

                immatriculation = exemplaire.immatriculation

                # ==================================================
                # RESTAURATION DU KILOMÉTRAGE
                # ==================================================
                kilometrage_rollback = (
                        exemplaire.kilometres_rollback or 0
                )
                kilometrage_rollback_boite = (
                        exemplaire.kilometres_boite_rollback or 0
                )
                kilometrage_rollback_moteur = (
                        exemplaire.kilometres_moteur_rollback or 0
                )
                kilometrage_rollback_embrayage = (
                        exemplaire.kilometres_embrayage_rollback or 0
                )

                exemplaire.kilometres_chassis = (
                    kilometrage_rollback
                )
                exemplaire.kilometres_boite = (
                    kilometrage_rollback_boite
                )
                exemplaire.kilometres_moteur = (
                    kilometrage_rollback_moteur
                )
                exemplaire.kilometres_embrayage = (
                    kilometrage_rollback_embrayage
                )

                exemplaire.save(
                    update_fields=[
                        "kilometres_chassis",
                        "kilometres_boite",
                        "kilometres_moteur",
                        "kilometres_embrayage"
                    ]
                )

                # ==================================================
                # SUPPRESSION CHECKUP
                # ==================================================
                carrosserie_interne.delete()

                # ==================================================
                # SUPPRESSION MAINTENANCE ASSOCIÉE
                # ==================================================
                if maintenance:
                    maintenance.delete()
                # ==================================================
                # USER LOG
                # ==================================================
                ACTION_SUPPRESSION_CAR_INT = gettext_noop(
                    "Suppression du contrôle de la carrosserie"
                )

                UserLog.objects.create(
                    utilisateur=request.user,
                    action=(
                        f"{ACTION_SUPPRESSION_CAR_INT} - "
                        f"{immatriculation}"
                    )
                )

            messages.success(
                request,
                _("Contrôle de la carrosserie supprimé avec succès.")
            )

            return redirect(
                "carrosserie_interne:carrosserie_interne_list",
                exemplaire_id=exemplaire.id
            )

        except Exception as e:

            messages.error(
                request,
                _("Erreur lors de la suppression : %(erreur)s")
                % {
                    "erreur": str(e)
                }
            )

            return redirect(
                f"{reverse('carrosserie_interne:carrosserie_interne_list', kwargs={'exemplaire_id': exemplaire.id})}?deleted=1"
            )

    # ==================================================
    # GET → CONFIRMATION
    # ==================================================
    return render(
        request,
        "carrosserie_interne/delete_carrosserie_interne.html",
        {
            "carrosserie_interne": carrosserie_interne,
            "exemplaire": exemplaire,
        }
    )









@login_required
def carrosserie_interne_pdf_view(request, carrosserie_id):
    tenant = request.user.societe


    carrosserie = get_object_or_404(
        CarrosserieInterne.objects.select_related(
            "maintenance",
            "voiture_exemplaire",
            "main_oeuvre",
            "tech_technicien",
            "tech_societe",
        ),
        id=carrosserie_id,
    )

    rapport = carrosserie.generer_rapport_remplacement()

    html_string = render_to_string(
        "carrosserie_interne/carrosserie_interne_pdf.html",
        {
            "carrosserie": carrosserie,
            "rapport": rapport,
            "pieces_utilisees": rapport["lignes"],
            "total_pieces": rapport["total_general"],
            "date_export": timezone.now(),
            "societe": tenant,
        },
        request=request,
    )

    pdf = HTML(
        string=html_string,
        base_url=request.build_absolute_uri("/"),
    ).write_pdf()

    # =========================================================
    # IMMATRICULATION
    # =========================================================

    immatriculation = (
        carrosserie.voiture_exemplaire.immatriculation
        if carrosserie.voiture_exemplaire
        else "sans_immatriculation"
    )

    # =========================================================
    # TECHNICIEN
    # =========================================================

    technicien = (
            carrosserie.tech_nom_technicien
            or "technicien_inconnu"
    )

    # Nettoyage pour le nom du fichier
    technicien = str(technicien).replace(" ", "_")
    immatriculation = str(immatriculation).replace(" ", "_")

    # =========================================================
    # DATE
    # =========================================================

    date_pdf = (
        carrosserie.date.strftime("%Y-%m-%d")
        if carrosserie.date
        else timezone.now().strftime("%Y-%m-%d")
    )

    # =========================================================
    # TITRE / NOM DU PDF
    # =========================================================

    nom_fichier = (
        f"{_('Carrosserie')}_{technicien}_{immatriculation}_{date_pdf}.pdf"
    )

    response = HttpResponse(
        pdf,
        content_type="application/pdf",
    )

    response["Content-Disposition"] = (
        f'inline; filename="{nom_fichier}"'
    )

    return response
