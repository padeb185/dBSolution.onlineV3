from django.core.exceptions import ValidationError
from django.shortcuts import redirect, render
from django.contrib import messages
from django.db import transaction, models
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.generic import ListView
from maintenance.models import Maintenance
from utilisateurs.models import UserLog
from voiture.voiture_exemplaire.models import VoitureExemplaire
from django.db.models import Q
from django.utils.translation import gettext_lazy as _, gettext_noop
from .forms import NiveauForm
from .models import Niveau
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from django.template.loader import render_to_string
from django.http import HttpResponse
from django.utils import timezone
from weasyprint import HTML



# -----------------------------
# Classe ListView pour checkup
# -----------------------------
@method_decorator([login_required, never_cache], name='dispatch')
class NiveauxListView(ListView):
    model = Niveau
    template_name = "niveaux/niveaux_list.html"
    context_object_name = "niveaux"
    ordering = ["-id"]

    def get_queryset(self):
        queryset = Niveau.objects.select_related(
            "voiture_exemplaire", "maintenance", "tech_societe"
        )

        # Filtrer par société : inclure les objets NULL ou ceux de la société de l'utilisateur
        societe = getattr(self.request.user, "societe", None)
        if societe:
            queryset = queryset.filter(
                models.Q(tech_societe=societe) | models.Q(tech_societe__isnull=True)
            )

        return queryset.order_by(*self.ordering)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        exemplaire_id = self.kwargs.get("exemplaire_id")
        context["exemplaire"] = get_object_or_404(
            VoitureExemplaire,
            id=exemplaire_id
        )

        context["is_checkup_allowed"] = self.request.user.role in [
            "direction",
            "mecanicien",
            "chef_mecanicien",
            "magasinier",
        ]

        return context





@login_required
def niveau_form_view(request, exemplaire_id):

    tenant = request.user.societe
    role = request.user.role

    maintenance = None  # 👈 important pour éviter UnboundLocalError


    # 🔎 Récupération exemplaire
    exemplaire = get_object_or_404(
        VoitureExemplaire.objects.filter(
            Q(client__societe=tenant) |
            Q(client__isnull=True, societe=tenant)
        ),
        id=exemplaire_id
    )

    # 🔐 rôles autorisés
    roles_autorises = [
        "mecanicien",
        "apprenti",
        "magasinier",
        "chef_mecanicien",
        "direction"
    ]

    if role not in roles_autorises:
        messages.error(request, _("Accès refusé"))
        return redirect("utilisateurs:dashboard")

    # =========================
    # POST
    # =========================
    if request.method == "POST":

        form = NiveauForm(
            request.POST,
            user=request.user,
            exemplaire=exemplaire
        )

        if form.is_valid():

            try:
                with transaction.atomic():

                    # ====================================================
                    # CRÉATION DE L'OBJET NETTOYAGE
                    # ====================================================

                    niveau = form.save(commit=False)

                    # IMPORTANT :
                    # niveau existe maintenant avant assign_technicien()
                    niveau.assign_technicien(request.user)

                    niveau.voiture_exemplaire = exemplaire
                    niveau.societe = tenant
                    niveau.immatriculation = exemplaire.immatriculation

                    # ====================================================
                    # KILOMÉTRAGE
                    # ====================================================

                    # ✅ On conserve le kilométrage précédent
                    ancien_kilometrage = (
                            exemplaire.kilometres_chassis or 0
                    )
                    ancien_kilometrage_boite = (
                            exemplaire.kilometres_boite or 0
                    )

                    ancien_kilometrage_moteur = (
                            exemplaire.kilometres_moteur or 0
                    )

                    ancien_kilometrage_embrayage = (
                            exemplaire.kilometres_embrayage or 0
                    )

                    km = form.cleaned_data.get(
                        "kilometrage_niveaux"
                    )

                    kilometrage_variation = 0

                    if km is not None:

                        if km < ancien_kilometrage:
                            raise ValueError(
                                _(
                                    "Le kilométrage du contrôle des niveaux "
                                    "ne peut pas être inférieur au kilométrage "
                                    "actuel du véhicule."
                                )
                            )

                        kilometrage_variation = (
                                km - ancien_kilometrage
                        )

                        # =========================
                        # ROLLBACK AVANT INTERVENTION
                        # =========================

                        exemplaire.kilometres_rollback = (
                            ancien_kilometrage
                        )

                        exemplaire.kilometres_boite_rollback = (
                            ancien_kilometrage_boite
                        )

                        exemplaire.kilometres_moteur_rollback = (
                            ancien_kilometrage_moteur
                        )

                        exemplaire.kilometres_embrayage_rollback = (
                            ancien_kilometrage_embrayage
                        )

                        # =========================
                        # DATE INTERVENTION
                        # =========================

                        exemplaire.date_derniere_intervention = (
                            timezone.localtime(
                                timezone.now()
                            ).date()
                        )

                        # =========================
                        # NOUVEAU KILOMÉTRAGE
                        # =========================

                        exemplaire.kilometres_chassis = km

                        # Recalcule :
                        # - kilometres_moteur
                        # - kilometres_boite
                        # - variation_kilometres
                        exemplaire.update_kilometres()

                        # =========================
                        # UNE SEULE SAUVEGARDE
                        # =========================

                        exemplaire.save(
                            update_fields=[
                                "kilometres_chassis",
                                "date_derniere_intervention",

                                # Rollback
                                "kilometres_rollback",
                                "kilometres_boite_rollback",
                                "kilometres_moteur_rollback",
                                "kilometres_embrayage_rollback",

                                # Valeurs recalculées
                                "kilometres_moteur",
                                "kilometres_boite",
                                "kilometres_embrayage",
                                "variation_kilometres",
                            ]
                        )

                    # 🔴 maintenance unique
                    maintenance = Maintenance.objects.create(
                        societe=request.user.societe,
                        voiture_exemplaire=exemplaire,
                        immatriculation=exemplaire.immatriculation,
                        date_intervention=timezone.now().date(),
                        kilometres_chassis=exemplaire.kilometres_chassis,
                        kilometres_dernier_entretien=exemplaire.kilometres_dernier_entretien,
                        type_maintenance=Maintenance.TypeMaintenance.NIVEAUX,
                        tag=Maintenance.Tag.JAUNE,

                        # 👨‍🔧 utilisateur ayant réalisé la maintenance
                        tech_technicien=request.user,
                        tech_societe=request.user.societe,
                        tech_nom_technicien=f"{request.user.prenom} {request.user.nom}",
                        tech_role_technicien=request.user.role,
                    )

                    # 🔧 Affectation spécifique selon le rôle
                    if role == "mecanicien":
                        maintenance.mecanicien = request.user

                    elif role == "chef_mecanicien":
                        maintenance.chef_mecanicien = request.user

                    elif role == "apprenti":
                        maintenance.apprentis = request.user

                    maintenance.save()

                    niveau.maintenance = maintenance
                    niveau.voiture_exemplaire = exemplaire
                    niveau.societe = tenant
                    niveau.immatriculation = exemplaire.immatriculation

                    # Kilométrage saisi
                    niveau.kilometrage_niveaux = km

                    # Variation
                    # # kilométrage AVANT le niveau
                    niveau.kilometres_chassis = (
                        ancien_kilometrage
                    )
                    niveau.kilometres_boite = (
                        ancien_kilometrage_boite
                    )
                    niveau.kilometres_moteur = (
                        ancien_kilometrage_moteur
                    )
                    niveau.kilometres_embrayage = (
                        ancien_kilometrage_embrayage
                    )

                    # différence entre ancien et nouveau kilométrage
                    niveau.kilometrage_variation = (
                        kilometrage_variation
                    )

                    # 👨‍🔧 technicien
                    niveau.assign_technicien(request.user)

                    # 👨‍🔧 dernier technicien maintenance
                    niveau.tech_last_maintained_by = request.user

                    niveau.save()

                    # Technicien
                    niveau.assign_technicien(
                        request.user
                    )

                    # Dernier technicien
                    niveau.tech_last_maintained_by = (
                        request.user
                    )



                    niveau.save()



                    ACTION_CONTROLE_NIVEAUX = gettext_noop(
                        "Contrôle des Niveaux"
                    )

                    UserLog.objects.create(
                        utilisateur=request.user,
                        action=f"{ACTION_CONTROLE_NIVEAUX} - {exemplaire.immatriculation}"
                    )


                messages.success(request, _("Controle des niveaux enregistré avec succès."))

                return redirect(
                    f"{reverse('niveaux:niveaux_list', kwargs={'exemplaire_id': exemplaire.id})}?saved=1"
                )


            except Exception as e:
                messages.error(request, _(f"Erreur lors de l'enregistrement : {str(e)}"))
        else:
            messages.error(request, _("Le formulaire contient des erreurs."))

    else:
        niveau = Niveau(
            voiture_exemplaire=exemplaire,
            kilometres_chassis=(
                    exemplaire.kilometres_chassis or 0
            ),

            kilometres_moteur=(
                    exemplaire.kilometres_moteur or 0
            ),

            kilometres_boite=(
                    exemplaire.kilometres_boite or 0
            ),

            kilometres_embrayage=(
                    exemplaire.kilometres_embrayage or 0
            ),
        )

        niveau.assign_technicien(request.user)  # 👈 AJOUT IMPORTANT

        form = NiveauForm(
            instance=niveau,
            user=request.user,
            exemplaire=exemplaire
        )

    return render(request, 'niveaux/niveau_form.html', {
        "exemplaire": exemplaire,
        "immatriculation": exemplaire.immatriculation,
        "maintenance": maintenance,
        "form": form,
        "now": timezone.now(),
    })



# ------------
# Vue détail checkup
# -----------------------------
@never_cache
@login_required
def niveau_detail_view(request, niveau_id):
    niveau = get_object_or_404(
        Niveau.objects.select_related("voiture_exemplaire"),
        id=niveau_id
    )

    context = {
        "niveau": niveau,
        "exemplaire": niveau.voiture_exemplaire,
    }
    return render(request, "niveaux/niveaux_detail.html", context)







@login_required
def modifier_niveau_view(request, niveau_id):

    tenant = request.user.societe

    # =========================
    # RÉCUPÉRATION NIVEAU
    # =========================
    niveau = get_object_or_404(
        Niveau.objects.select_related(
            "voiture_exemplaire",
            "maintenance",
        ),
        id=niveau_id
    )

    exemplaire = niveau.voiture_exemplaire

    # =========================
    # POST
    # =========================
    if request.method == "POST":

        form = NiveauForm(
            request.POST,
            instance=niveau,
            user=request.user,
            exemplaire=exemplaire
        )

        if form.is_valid():

            try:
                with transaction.atomic():

                    # ==================================================
                    # NOUVEAU KILOMÉTRAGE SAISI
                    # ==================================================
                    km = form.cleaned_data.get(
                        "kilometrage_niveaux"
                    )

                    if km is not None:
                        km = int(km)

                    # ==================================================
                    # VALEURS ACTUELLES = ROLLBACK LOCAL
                    # ==================================================
                    rollback_chassis = (
                            exemplaire.kilometres_chassis or 0
                    )

                    rollback_moteur = (
                            exemplaire.kilometres_moteur or 0
                    )

                    rollback_boite = (
                            exemplaire.kilometres_boite or 0
                    )

                    rollback_embrayage = (
                            exemplaire.kilometres_embrayage or 0
                    )

                    # ==================================================
                    # VALIDATION
                    # ==================================================
                    if km is not None:

                        if km < 0:
                            raise ValidationError(
                                _(
                                    "Le kilométrage ne peut pas "
                                    "être négatif."
                                )
                            )

                        if km < rollback_chassis:
                            raise ValidationError(
                                _(
                                    "Le kilométrage ne peut pas être "
                                    "inférieur à %(km)s km."
                                ) % {
                                    "km": rollback_chassis
                                }
                            )

                    # ==================================================
                    # ESSUYAGE
                    # ==================================================
                    niveau = form.save(
                        commit=False
                    )

                    niveau.voiture_exemplaire = (
                        exemplaire
                    )

                    # ==================================================
                    # ROLLBACK LOCAL
                    # ==================================================
                    niveau.kilometres_chassis = (
                        rollback_chassis
                    )

                    niveau.kilometres_moteur = (
                        rollback_moteur
                    )

                    niveau.kilometres_boite = (
                        rollback_boite
                    )

                    niveau.kilometres_embrayage = (
                        rollback_embrayage
                    )

                    # ==================================================
                    # NOUVEAU KILOMÉTRAGE
                    # ==================================================
                    niveau.kilometrage_net_ext = km

                    # ==================================================
                    # VARIATION
                    # ==================================================
                    if km is not None:
                        niveau.kilometrage_variation = (
                                km - rollback_chassis
                        )
                    else:
                        niveau.kilometrage_variation = 0

                    # ==================================================
                    # TECHNICIEN
                    # ==================================================
                    niveau.assign_technicien(
                        request.user
                    )

                    niveau.tech_last_maintained_by = (
                        request.user
                    )

                    # ==================================================
                    # MISE À JOUR DU VÉHICULE
                    # ==================================================
                    if km is not None:
                        exemplaire.kilometres_chassis = km

                        exemplaire.date_derniere_intervention = (
                            timezone.localtime(
                                timezone.now()
                            ).date()
                        )

                        # Le save() du modèle VoitureExemplaire
                        # doit gérer update_kilometres()
                        exemplaire.save()

                    # ==================================================
                    # SAUVEGARDE Freins
                    # ==================================================
                    niveau.save()

                    form.save_m2m()

                    # =========================
                    # LOG
                    # =========================


                    ACTION_MODIFICATION_CONTROLE_NIVEAUX = gettext_noop(
                        "Modification du contrôle des niveaux"
                    )

                    UserLog.objects.create(
                        utilisateur=request.user,
                        action=f"{ACTION_MODIFICATION_CONTROLE_NIVEAUX} - {exemplaire.immatriculation}"
                    )

                messages.success(
                    request,
                    _("Contrôle des niveaux modifié avec succès !")
                )

                return redirect(
                    f"{reverse('niveaux:niveaux_detail', kwargs={'niveau_id': niveau.id})}?saved=1"
                )

            except ValidationError as e:

                form.add_error(
                    "kilometrage_niveau",
                    e
                )

                messages.error(
                    request,
                    _("Kilométrage invalide.")
                )

            except Exception as e:

                messages.error(
                    request,
                    _("Erreur lors de la modification : %(error)s") % {
                        "error": str(e)
                    }
                )

        else:

            messages.error(
                request,
                _("Le formulaire contient des erreurs.")
            )

    # =========================
    # GET
    # =========================
    else:

        form = NiveauForm(
            instance=niveau,
            user=request.user,
            exemplaire=exemplaire
        )

    return render(
        request,
        "niveaux/modifier_niveaux.html",
        {
            "form": form,
            "niveau": niveau,
            "exemplaire": exemplaire,
        }
    )







@never_cache
@login_required
def delete_niveau_view(request, niveau_id):

    tenant = request.user.societe
    role = request.user.role

    # ==================================================
    # AUTORISATIONS
    # ==================================================
    roles_autorises = [
        "direction",
        "chef_mecanicien",
    ]

    if (
        role not in roles_autorises
        and not request.user.is_superuser
    ):
        messages.error(
            request,
            _("Accès refusé")
        )
        return redirect(
            "utilisateurs:dashboard"
        )

    # ==================================================
    # RÉCUPÉRATION CHECKUP
    # ==================================================
    niveau = get_object_or_404(
        Niveau.objects.select_related(
            "voiture_exemplaire",
            "maintenance",
        ),
        id=niveau_id,
    )

    exemplaire = niveau.voiture_exemplaire
    maintenance = niveau.maintenance

    # ==================================================
    # VÉRIFICATION TENANT
    # ==================================================
    if not (
        (
            exemplaire.client
            and exemplaire.client.societe == tenant
        )
        or
        (
            exemplaire.client is None
            and exemplaire.societe == tenant
        )
    ):
        messages.error(
            request,
            _("Accès refusé")
        )
        return redirect(
            "utilisateurs:dashboard"
        )

    # ==================================================
    # DELETE
    # ==================================================
    if request.method == "POST":

        try:
            with transaction.atomic():

                immatriculation = exemplaire.immatriculation

                # ==================================================
                # RESTAURATION DU KILOMÉTRAGE
                # ==================================================
                kilometrage_rollback = (
                        exemplaire.kilometres_rollback or 0
                )
                kilometrage_rollback_boite = (
                        exemplaire.kilometres_boite_rollback or 0
                )
                kilometrage_rollback_moteur = (
                        exemplaire.kilometres_moteur_rollback or 0
                )
                kilometrage_rollback_embrayage = (
                        exemplaire.kilometres_embrayage_rollback or 0
                )




                exemplaire.kilometres_chassis = (
                    kilometrage_rollback
                )
                exemplaire.kilometres_boite = (
                    kilometrage_rollback_boite
                )
                exemplaire.kilometres_moteur = (
                    kilometrage_rollback_moteur
                )
                exemplaire.kilometres_embrayage = (
                    kilometrage_rollback_embrayage
                )

                exemplaire.save(
                    update_fields=[
                        "kilometres_chassis",
                        "kilometres_boite",
                        "kilometres_embrayage",
                        "kilometres_moteur"
                    ]
                )

                # ==================================================
                # SUPPRESSION CHECKUP
                # ==================================================
                niveau.delete()

                # ==================================================
                # SUPPRESSION MAINTENANCE ASSOCIÉE
                # ==================================================
                if maintenance:
                    maintenance.delete()

                # ==================================================
                # USER LOG
                # ==================================================
                ACTION_SUPPRESSION_NIVEAU = gettext_noop(
                    "Suppression du contrôle des niveaux"
                )

                UserLog.objects.create(
                    utilisateur=request.user,
                    action=(
                        f"{ACTION_SUPPRESSION_NIVEAU} - "
                        f"{immatriculation}"
                    )
                )

            messages.success(
                request,
                _("Contrôle des niveaux supprimé avec succès.")
            )

            return redirect(
                f"{reverse('niveaux:niveaux_list', kwargs={'exemplaire_id': exemplaire.id})}?deleted=1"
            )


        except Exception as e:

            messages.error(
                request,
                _("Erreur lors de la suppression : %(erreur)s")
                % {
                    "erreur": str(e)
                }
            )

    # ==================================================
    # GET → CONFIRMATION
    # ==================================================
    return render(
        request,
        "niveaux/delete_niveau.html",
        {
            "niveau": niveau,
            "exemplaire": exemplaire,
        }
    )






@login_required
def niveau_pdf_view(request, niveau_id):
    tenant = request.user.societe


    niveau = get_object_or_404(
        Niveau.objects.select_related(
            "maintenance",
            "voiture_exemplaire",
            "main_oeuvre",
            "tech_technicien",
            "tech_societe",
        ),
        id=niveau_id
    )

    # Génération du rapport des liquides / produits utilisés
    rapport = niveau.generer_rapport_remplacement()

    html_string = render_to_string(
        "niveaux/niveau_detail_pdf.html",
        {
            "niveau": niveau,
            "rapport": rapport,
            "date_export": timezone.now(),
            "societe": tenant,
        },
        request=request
    )

    pdf = HTML(
        string=html_string,
        base_url=request.build_absolute_uri("/")
    ).write_pdf()

    # =========================================================
    # IMMATRICULATION
    # =========================================================

    immatriculation = (
        niveau.voiture_exemplaire.immatriculation
        if niveau.voiture_exemplaire
        else "sans_immatriculation"
    )

    # =========================================================
    # TECHNICIEN
    # =========================================================

    technicien = (
            niveau.tech_nom_technicien
            or "technicien_inconnu"
    )

    # Nettoyage pour le nom du fichier
    technicien = str(technicien).replace(" ", "_")
    immatriculation = str(immatriculation).replace(" ", "_")

    # =========================================================
    # DATE
    # =========================================================

    date_pdf = (
        niveau.date.strftime("%Y-%m-%d")
        if niveau.date
        else timezone.now().strftime("%Y-%m-%d")
    )

    # =========================================================
    # TITRE / NOM DU PDF
    # =========================================================

    nom_fichier = (
        f"{_('Niveaux')}_{technicien}_{immatriculation}_{date_pdf}.pdf"
    )

    response = HttpResponse(
        pdf,
        content_type="application/pdf",
    )

    response["Content-Disposition"] = (
        f'inline; filename="{nom_fichier}"'
    )

    return response
