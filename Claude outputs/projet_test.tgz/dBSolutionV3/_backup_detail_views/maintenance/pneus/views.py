from django.shortcuts import redirect, render
from django.contrib import messages
from django.db import transaction, models
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.generic import ListView
from maintenance.models import Maintenance
from utilisateurs.models import UserLog
from voiture.voiture_exemplaire.models import VoitureExemplaire
from django.db.models import Q
from django.utils.translation import gettext_lazy as _, gettext_noop
from maintenance.pneus.forms import ControlePneusForm
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from django.template.loader import render_to_string
from django.http import HttpResponse
from django.utils import timezone
from weasyprint import HTML
from .models import ControlePneus
from django.core.exceptions import ValidationError




# -----------------------------
# Classe ListView pour checkup
# -----------------------------
@method_decorator([login_required, never_cache], name='dispatch')
class PneusListView(ListView):
    model = ControlePneus
    template_name = "pneus/pneus_list.html"
    context_object_name = "pneus"
    ordering = ["-date"]

    def get_queryset(self):
        exemplaire_id = self.kwargs.get("exemplaire_id")

        queryset = ControlePneus.objects.select_related(
            "voiture_exemplaire", "maintenance", "tech_societe"
        )

        societe = getattr(self.request.user, "societe", None)
        if societe:
            queryset = queryset.filter(
                models.Q(tech_societe=societe) | models.Q(tech_societe__isnull=True)
            )

        return queryset.order_by("date", "created_at")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        exemplaire_id = self.kwargs.get("exemplaire_id")
        context["exemplaire"] = get_object_or_404(
            VoitureExemplaire,
            id=exemplaire_id
        )

        context["is_checkup_allowed"] = self.request.user.role in [
            "direction",
            "mecanicien",
            "chef_mecanicien",
            "magasinier",
        ]

        return context





@never_cache
@login_required
def controle_pneus_view(request, exemplaire_id):

    tenant = request.user.societe
    role = request.user.role

    maintenance = None

    # 🔎 Récupération exemplaire
    exemplaire = get_object_or_404(
        VoitureExemplaire.objects.filter(
            Q(client__societe=tenant) |
            Q(client__isnull=True, societe=tenant)
        ),
        id=exemplaire_id
    )

    # 🔐 rôles autorisés
    roles_autorises = [
        "mecanicien",
        "apprenti",
        "magasinier",
        "chef_mecanicien",
        "direction",
    ]

    if role not in roles_autorises:
        messages.error(
            request,
            _("Accès refusé")
        )
        return redirect("utilisateurs:dashboard")

    # =========================
    # POST
    # =========================
    if request.method == "POST":

        form = ControlePneusForm(
            request.POST,
            user=request.user,
            exemplaire=exemplaire
        )

        if form.is_valid():

            try:
                with transaction.atomic():

                    # ====================================================
                    # CRÉATION OBJET PNEUS
                    # ====================================================
                    pneus = form.save(commit=False)

                    pneus.assign_technicien(
                        request.user
                    )

                    pneus.voiture_exemplaire = exemplaire
                    pneus.societe = tenant
                    pneus.immatriculation = (
                        exemplaire.immatriculation
                    )

                    # ====================================================
                    # KILOMÉTRAGE
                    # ====================================================
                    # ✅ On conserve le kilométrage précédent
                    ancien_kilometrage = (
                            exemplaire.kilometres_chassis or 0
                    )
                    ancien_kilometrage_boite = (
                            exemplaire.kilometres_boite or 0
                    )

                    ancien_kilometrage_moteur = (
                            exemplaire.kilometres_moteur or 0
                    )

                    ancien_kilometrage_embrayage = (
                            exemplaire.kilometres_embrayage or 0
                    )

                    km = form.cleaned_data.get(
                        "kilometrage_pneus"
                    )

                    kilometrage_variation = 0

                    if km is not None:

                        km = int(km)

                        if km < ancien_kilometrage:
                            raise ValueError(
                                _(
                                    "Le kilométrage du contrôle des pneus "
                                    "ne peut pas être inférieur au kilométrage "
                                    "actuel du véhicule."
                                )
                            )

                        # Calcul avant mise à jour véhicule
                        kilometrage_variation = (
                            km - ancien_kilometrage
                        )


                        # Mise à jour du kilométrage véhicule
                        # =========================
                        # ROLLBACK AVANT INTERVENTION
                        # =========================

                        exemplaire.kilometres_rollback = (
                            ancien_kilometrage
                        )

                        exemplaire.kilometres_boite_rollback = (
                            ancien_kilometrage_boite
                        )

                        exemplaire.kilometres_moteur_rollback = (
                            ancien_kilometrage_moteur
                        )

                        exemplaire.kilometres_embrayage_rollback = (
                            ancien_kilometrage_embrayage
                        )

                        # =========================
                        # DATE INTERVENTION
                        # =========================

                        exemplaire.date_derniere_intervention = (
                            timezone.localtime(
                                timezone.now()
                            ).date()
                        )

                        # =========================
                        # NOUVEAU KILOMÉTRAGE
                        # =========================

                        exemplaire.kilometres_chassis = km

                        # Recalcule :
                        # - kilometres_moteur
                        # - kilometres_boite
                        # - variation_kilometres
                        exemplaire.update_kilometres()

                        # =========================
                        # UNE SEULE SAUVEGARDE
                        # =========================

                        exemplaire.save(
                            update_fields=[
                                "kilometres_chassis",
                                "date_derniere_intervention",

                                # Rollback
                                "kilometres_rollback",
                                "kilometres_boite_rollback",
                                "kilometres_moteur_rollback",
                                "kilometres_embrayage_rollback",

                                # Valeurs recalculées
                                "kilometres_moteur",
                                "kilometres_boite",
                                "kilometres_embrayage",
                                "variation_kilometres",
                            ]
                        )

                    # ====================================================
                    # MAINTENANCE
                    # ====================================================
                    # 🔴 maintenance unique
                    maintenance = Maintenance.objects.create(
                        societe=request.user.societe,
                        voiture_exemplaire=exemplaire,
                        immatriculation=exemplaire.immatriculation,
                        date_intervention=timezone.now().date(),
                        kilometres_chassis=exemplaire.kilometres_chassis,
                        kilometres_dernier_entretien=exemplaire.kilometres_dernier_entretien,
                        type_maintenance=Maintenance.TypeMaintenance.PNEUS,
                        tag=Maintenance.Tag.JAUNE,

                        # 👨‍🔧 utilisateur ayant réalisé la maintenance
                        tech_technicien=request.user,
                        tech_societe=request.user.societe,
                        tech_nom_technicien=f"{request.user.prenom} {request.user.nom}",
                        tech_role_technicien=request.user.role,
                    )

                    # 🔧 Affectation spécifique selon le rôle
                    if role == "mecanicien":
                        maintenance.mecanicien = request.user

                    elif role == "chef_mecanicien":
                        maintenance.chef_mecanicien = request.user

                    elif role == "apprenti":
                        maintenance.apprentis = request.user

                    maintenance.save()

                    # ====================================================
                    # CONTRÔLE PNEUS
                    # ====================================================
                    pneus.maintenance = maintenance
                    pneus.voiture_exemplaire = exemplaire
                    pneus.societe = tenant
                    pneus.immatriculation = (
                        exemplaire.immatriculation
                    )

                    # Kilométrage saisi
                    pneus.kilometrage_pneus = km

                    # Variation
                    # # kilométrage AVANT le pneus
                    pneus.kilometres_chassis = (
                        ancien_kilometrage
                    )
                    pneus.kilometres_boite = (
                        ancien_kilometrage_boite
                    )
                    pneus.kilometres_moteur = (
                        ancien_kilometrage_moteur
                    )
                    pneus.kilometres_embrayage = (
                        ancien_kilometrage_embrayage
                    )


                    # différence entre ancien et nouveau kilométrage
                    pneus.kilometrage_variation = (
                        kilometrage_variation
                    )

                    # 👨‍🔧 technicien
                    pneus.assign_technicien(request.user)

                    # 👨‍🔧 dernier technicien maintenance
                    pneus.tech_last_maintained_by = request.user

                    pneus.save()


                    # ====================================================
                    # LOG
                    # ====================================================


                    ACTION_CONTROLE_PNEUS = gettext_noop(
                        "Contrôle des pneus"
                    )

                    UserLog.objects.create(
                        utilisateur=request.user,
                        action=f"{ACTION_CONTROLE_PNEUS} - {exemplaire.immatriculation}"
                    )

                messages.success(
                    request,
                    _("Contrôle pneus enregistré avec succès.")
                )

                return redirect(
                    f"{reverse('pneus:pneus_list', kwargs={'exemplaire_id': exemplaire.id})}?saved=1"
                )


            except Exception as e:

                messages.error(
                    request,
                    _("Erreur lors de l'enregistrement : %(error)s") % {
                        "error": str(e)
                    }
                )

        else:

            messages.error(
                request,
                _("Le formulaire contient des erreurs.")
            )

    # =========================
    # GET
    # =========================
    else:

        pneus = ControlePneus(
            voiture_exemplaire=exemplaire,
            kilometres_chassis=(
                    exemplaire.kilometres_chassis or 0
            ),

            kilometres_moteur=(
                    exemplaire.kilometres_moteur or 0
            ),

            kilometres_boite=(
                    exemplaire.kilometres_boite or 0
            ),

            kilometres_embrayage=(
                    exemplaire.kilometres_embrayage or 0
            ),
        )

        pneus.assign_technicien(
            request.user
        )

        form = ControlePneusForm(
            instance=pneus,
            user=request.user,
            exemplaire=exemplaire
        )

    # =========================
    # TEMPLATE
    # =========================
    return render(
        request,
        "pneus/controle_pneus.html",
        {
            "exemplaire": exemplaire,
            "immatriculation": (
                exemplaire.immatriculation
            ),
            "maintenance": maintenance,
            "form": form,
            "now": timezone.now(),
        }
    )





# ------------
# Vue détail checkup
# -----------------------------


@never_cache
@login_required
def pneus_detail_view(request, pneu_id):
    pneus = get_object_or_404(
        ControlePneus.objects.select_related("voiture_exemplaire"),
        id=pneu_id
    )

    context = {
        "pneus": pneus,
        "exemplaire": pneus.voiture_exemplaire,
    }
    return render(request, "pneus/pneus_detail.html", context)






@login_required
def modifier_pneus_view(request, pneu_id):

    tenant = request.user.societe

    pneus = get_object_or_404(
        ControlePneus.objects.select_related(
            "voiture_exemplaire"
        ),
        id=pneu_id
    )

    exemplaire = pneus.voiture_exemplaire

    if request.method == "POST":

        form = ControlePneusForm(
            request.POST,
            instance=pneus,
            user=request.user,
            exemplaire=exemplaire
        )

        if form.is_valid():

            try:
                with transaction.atomic():

                    # ==================================================
                    # NOUVEAU KILOMÉTRAGE SAISI
                    # ==================================================
                    km = form.cleaned_data.get(
                        "kilometrage_pneus"
                    )

                    if km is not None:
                        km = int(km)

                    # ==================================================
                    # VALEURS ACTUELLES = ROLLBACK LOCAL
                    # ==================================================
                    rollback_chassis = (
                            exemplaire.kilometres_chassis or 0
                    )

                    rollback_moteur = (
                            exemplaire.kilometres_moteur or 0
                    )

                    rollback_boite = (
                            exemplaire.kilometres_boite or 0
                    )

                    rollback_embrayage = (
                            exemplaire.kilometres_embrayage or 0
                    )

                    # ==================================================
                    # VALIDATION
                    # ==================================================
                    if km is not None:

                        if km < 0:
                            raise ValidationError(
                                _(
                                    "Le kilométrage ne peut pas "
                                    "être négatif."
                                )
                            )

                        if km < rollback_chassis:
                            raise ValidationError(
                                _(
                                    "Le kilométrage ne peut pas être "
                                    "inférieur à %(km)s km."
                                ) % {
                                    "km": rollback_chassis
                                }
                            )

                    # ==================================================
                    # ESSUYAGE
                    # ==================================================
                    pneus = form.save(
                        commit=False
                    )

                    pneus.voiture_exemplaire = (
                        exemplaire
                    )

                    # ==================================================
                    # ROLLBACK LOCAL
                    # ==================================================
                    pneus.kilometres_chassis = (
                        rollback_chassis
                    )

                    pneus.kilometres_moteur = (
                        rollback_moteur
                    )

                    pneus.kilometres_boite = (
                        rollback_boite
                    )

                    pneus.kilometres_embrayage = (
                        rollback_embrayage
                    )

                    # ==================================================
                    # NOUVEAU KILOMÉTRAGE
                    # ==================================================
                    pneus.kilometrage_net_ext = km

                    # ==================================================
                    # VARIATION
                    # ==================================================
                    if km is not None:
                        pneus.kilometrage_variation = (
                                km - rollback_chassis
                        )
                    else:
                        pneus.kilometrage_variation = 0

                    # ==================================================
                    # TECHNICIEN
                    # ==================================================
                    pneus.assign_technicien(
                        request.user
                    )

                    pneus.tech_last_maintained_by = (
                        request.user
                    )

                    # ==================================================
                    # MISE À JOUR DU VÉHICULE
                    # ==================================================
                    if km is not None:
                        exemplaire.kilometres_chassis = km

                        exemplaire.date_derniere_intervention = (
                            timezone.localtime(
                                timezone.now()
                            ).date()
                        )

                        # Le save() du modèle VoitureExemplaire
                        # doit gérer update_kilometres()
                        exemplaire.save()

                    # ==================================================
                    # SAUVEGARDE Freins
                    # ==================================================
                    pneus.save()

                    form.save_m2m()
                    # =========================
                    # LOG
                    # =========================



                    ACTION_MODIFICATION_CONTROLE_PNEUS = gettext_noop(
                        "Modification du contrôle des pneus"
                    )

                    UserLog.objects.create(
                        utilisateur=request.user,
                        action=f"{ACTION_MODIFICATION_CONTROLE_PNEUS} - {exemplaire.immatriculation}"
                    )

                messages.success(
                    request,
                    _(
                        "Contrôle des pneus modifié avec succès !"
                    )
                )

                return redirect(
                    f"{reverse('pneus:pneus_detail', kwargs={'pneu_id': pneus.id})}?saved=1"
                )

            except ValidationError as e:

                form.add_error(
                    "kilometrage_pneus",
                    e
                )

                messages.error(
                    request,
                    _("Kilométrage invalide")
                )

            except Exception as e:

                messages.error(
                    request,
                    _(
                        "Erreur lors de la modification : %(error)s"
                    ) % {
                        "error": str(e)
                    }
                )

        else:

            messages.error(
                request,
                _("Le formulaire contient des erreurs.")
            )



    else:

        form = ControlePneusForm(
            instance=pneus,
            user=request.user,
            exemplaire=exemplaire
        )

    return render(
        request,
        "pneus/modifier_pneus.html",
        {
            "form": form,
            "pneus": pneus,
            "exemplaire": exemplaire,
        }
    )



@never_cache
@login_required
def delete_pneus_view(request, pneu_id):

    tenant = request.user.societe
    role = request.user.role

    # ==================================================
    # AUTORISATIONS
    # ==================================================
    roles_autorises = [
        "direction",
        "chef_mecanicien",
    ]

    if (
        role not in roles_autorises
        and not request.user.is_superuser
    ):
        messages.error(
            request,
            _("Accès refusé")
        )
        return redirect(
            "utilisateurs:dashboard"
        )

    # ==================================================
    # RÉCUPÉRATION CHECKUP
    # ==================================================
    pneus = get_object_or_404(
        ControlePneus.objects.select_related(
            "voiture_exemplaire",
            "maintenance",
        ),
        id=pneu_id,
    )

    exemplaire = pneus.voiture_exemplaire
    maintenance = pneus.maintenance

    # ==================================================
    # VÉRIFICATION TENANT
    # ==================================================
    if not (
        (
            exemplaire.client
            and exemplaire.client.societe == tenant
        )
        or
        (
            exemplaire.client is None
            and exemplaire.societe == tenant
        )
    ):
        messages.error(
            request,
            _("Accès refusé")
        )
        return redirect(
            "utilisateurs:dashboard"
        )

    # ==================================================
    # DELETE
    # ==================================================
    if request.method == "POST":

        try:
            with transaction.atomic():

                immatriculation = exemplaire.immatriculation

                # ==================================================
                # RESTAURATION DU KILOMÉTRAGE
                # ==================================================
                kilometrage_rollback = (
                        exemplaire.kilometres_rollback or 0
                )
                kilometrage_rollback_boite = (
                        exemplaire.kilometres_boite_rollback or 0
                )
                kilometrage_rollback_moteur = (
                        exemplaire.kilometres_moteur_rollback or 0
                )
                kilometrage_rollback_embrayage = (
                        exemplaire.kilometres_embrayage_rollback or 0
                )



                exemplaire.kilometres_chassis = (
                    kilometrage_rollback
                )
                exemplaire.kilometres_boite = (
                    kilometrage_rollback_boite
                )
                exemplaire.kilometres_moteur = (
                    kilometrage_rollback_moteur
                )
                exemplaire.kilometres_embrayage = (
                    kilometrage_rollback_embrayage
                )


                exemplaire.save(
                    update_fields=[
                        "kilometres_chassis",
                        "kilometres_boite",
                        "kilometres_embrayage",
                        "kilometres_moteur"
                    ]
                )

                # ==================================================
                # SUPPRESSION CHECKUP
                # ==================================================
                pneus.delete()

                # ==================================================
                # SUPPRESSION MAINTENANCE ASSOCIÉE
                # ==================================================
                if maintenance:
                    maintenance.delete()

                # ==================================================
                # USER LOG
                # ==================================================
                ACTION_SUPPRESSION_PNEUS = gettext_noop(
                    "Suppression du contrôle des pneus"
                )

                UserLog.objects.create(
                    utilisateur=request.user,
                    action=(
                        f"{ACTION_SUPPRESSION_PNEUS} - "
                        f"{immatriculation}"
                    )
                )

            messages.success(
                request,
                _("Contrôle des pneus supprimé avec succès.")
            )

            return redirect(
                f"{reverse('pneus:pneus_list', kwargs={'exemplaire_id': exemplaire.id})}?deleted=1"
            )
        except Exception as e:

            messages.error(
                request,
                _("Erreur lors de la suppression : %(erreur)s")
                % {
                    "erreur": str(e)
                }
            )

            return redirect(
                "pneus:pneus_detail",
                 pneu_id=pneus.id,
            )

    # ==================================================
    # GET → CONFIRMATION
    # ==================================================
    return render(
        request,
        "pneus/delete_pneus.html",
        {
            "pneus": pneus,
            "exemplaire": exemplaire,
        }
    )









@login_required
def controle_pneus_pdf_view(request, controle_pneus_id):
    tenant = request.user.societe


    controle_pneus = get_object_or_404(
        ControlePneus.objects.select_related(
            "maintenance",
            "voiture_exemplaire",
            "voiture_pneus",
            "main_oeuvre",
            "tech_technicien",
            "tech_societe",
        ),
        id=controle_pneus_id
    )

    # Génération du rapport des pneus à remplacer ou remplacés
    rapport = controle_pneus.generer_rapport_remplacement()

    # Conserver uniquement les pièces avec une quantité > 0
    rapport["lignes"] = [
        ligne
        for ligne in rapport.get("lignes", [])
        if (ligne.get("quantite") or 0) > 0
    ]

    rapport["total_general"] = sum(
        ligne.get("total", 0) or 0
        for ligne in rapport["lignes"]
    )

    html_string = render_to_string(
        "pneus/controle_pneus_detail_pdf.html",
        {
            "controle_pneus": controle_pneus,
            "objet": controle_pneus,
            "rapport": rapport,
            "pieces_utilisees": rapport.get("lignes", []),
            "total_pieces": rapport.get("total_general", 0),
            "date_export": timezone.now(),
            "societe": tenant,
        },
        request=request
    )

    pdf = HTML(
        string=html_string,
        base_url=request.build_absolute_uri("/")
    ).write_pdf()

    # =========================================================
    # IMMATRICULATION
    # =========================================================

    immatriculation = (
        controle_pneus.voiture_exemplaire.immatriculation
        if controle_pneus.voiture_exemplaire
        else "sans_immatriculation"
    )

    # =========================================================
    # TECHNICIEN
    # =========================================================

    technicien = (
            controle_pneus.tech_nom_technicien
            or "technicien_inconnu"
    )

    # Nettoyage pour le nom du fichier
    technicien = str(technicien).replace(" ", "_")
    immatriculation = str(immatriculation).replace(" ", "_")

    # =========================================================
    # DATE
    # =========================================================

    date_pdf = (
        controle_pneus.date.strftime("%Y-%m-%d")
        if controle_pneus.date
        else timezone.now().strftime("%Y-%m-%d")
    )

    # =========================================================
    # TITRE / NOM DU PDF
    # =========================================================

    nom_fichier = (
        f"{_('Pneus')}_{technicien}_{immatriculation}_{date_pdf}.pdf"
    )

    response = HttpResponse(
        pdf,
        content_type="application/pdf",
    )

    response["Content-Disposition"] = (
        f'inline; filename="{nom_fichier}"'
    )

    return response
