from core.suppression import analyser_suppression, masquer
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import ProtectedError, RestrictedError
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.generic import ListView
from django_tenants.utils import tenant_context
from adresse.models import Adresse
from societe_cliente.models import SocieteCliente
from societe_cliente.forms import SocieteClienteForm
from django.utils.translation import gettext as _, gettext_noop
from utilisateurs.models import UserLog
from utils.securite import peut_supprimer, refuser_suppression





@method_decorator([login_required, never_cache], name="dispatch")
class SocieteClienteListView(ListView):
    model = SocieteCliente
    template_name = "societe_cliente/societe_cliente_list.html"
    context_object_name = "societe_clientes"
    paginate_by = 20
    ordering = ["nom_societe_cliente"]

    def dispatch(self, request, *args, **kwargs):
        self.tenant = getattr(request.user, "societe", None)

        if not self.tenant:
            messages.error(request, "Aucune société sélectionnée.")
            return redirect("dashboard")  # adapte la redirection

        return super().dispatch(request, *args, **kwargs)

    def get_queryset(self):
        societe = self.request.user.societe
        with tenant_context(self.tenant):
            return (
                SocieteCliente.objects.all()
                .order_by("nom_societe_cliente")
                .filter(societe=societe)
            )



@never_cache
@login_required
def societe_cliente_detail(request, societe_cliente_id):
    tenant = request.user.societe


    societe_cliente = get_object_or_404(
        SocieteCliente,
        id_societe_cliente=societe_cliente_id
    )

    adresse = societe_cliente.adresse

    return render(
        request,
        "societe_cliente/societe_cliente_detail.html",
        {
            "societe_cliente": societe_cliente,
            "adresse": adresse,
        },
    )




@login_required
def ajouter_societe_cliente_all(request):

    tenant = request.user.societe


    if request.method == "POST":

        form = SocieteClienteForm(request.POST)

        if form.is_valid():

            # Création adresse
            adresse = Adresse.objects.create(
                rue=form.cleaned_data.get("rue"),
                numero=form.cleaned_data.get("numero"),
                code_postal=form.cleaned_data.get("code_postal"),
                boite=form.cleaned_data.get("boite"),
                ville=form.cleaned_data.get("ville"),
                pays=form.cleaned_data.get("pays"),
                code_pays=form.cleaned_data.get("code_pays"),
            )

            # Création société
            societe_cliente = form.save(commit=False)
            societe_cliente.societe = tenant
            societe_cliente.adresse = adresse
            societe_cliente.save()

            messages.success(
                request,
                _("Société cliente ajoutée avec succès !")
            )
            return redirect(
                f"{reverse('societe_cliente:societe_cliente_list')}?saved=1"
            )


    else:
        form = SocieteClienteForm()

    return render(
        request,
        "societe_cliente/societe_cliente_form.html",
        {
            "form": form
        }
    )







@login_required
def modifier_societe_cliente(request, societe_cliente_id):

    tenant = request.user.societe

    societe_cliente = get_object_or_404(
        SocieteCliente,
        id_societe_cliente=societe_cliente_id
    )

    if request.method == "POST":

        form = SocieteClienteForm(
            request.POST,
            instance=societe_cliente
        )

        if form.is_valid():

            # -------------------------
            # MAJ ADRESSE
            # -------------------------
            adresse = societe_cliente.adresse

            adresse.rue = form.cleaned_data.get("rue")
            adresse.numero = form.cleaned_data.get("numero")
            adresse.code_postal = form.cleaned_data.get("code_postal")
            adresse.ville = form.cleaned_data.get("ville")
            adresse.pays = form.cleaned_data.get("pays")
            adresse.code_pays = form.cleaned_data.get("code_pays")

            adresse.save()

            # -------------------------
            # MAJ SOCIETE
            # -------------------------
            form.save()

            messages.success(
                request,
                _("Société cliente '%(nom)s' modifiée avec succès !") % {
                    "nom": societe_cliente.nom_societe_cliente,
                }
            )

            return redirect(
                f"{reverse('societe_cliente:societe_cliente_detail', kwargs={'societe_cliente_id': societe_cliente.id})}?saved=1"
            )

    else:

        initial = {}

        if societe_cliente.adresse:

            initial = {
                "rue": societe_cliente.adresse.rue,
                "numero": societe_cliente.adresse.numero,
                "code_postal": societe_cliente.adresse.code_postal,
                "ville": societe_cliente.adresse.ville,
                "pays": societe_cliente.adresse.pays,
                "code_pays": societe_cliente.adresse.code_pays,
            }

        form = SocieteClienteForm(
            instance=societe_cliente,
            initial=initial
        )

    return render(
        request,
        "societe_cliente/modifier_societe_cliente.html",
        {
            "form": form,
            "societe_cliente": societe_cliente,
        }
    )





ACTION_SUPPRESSION_SOCIETE_CLIENTE = gettext_noop("Suppression de la société cliente")


@login_required
def delete_societe_cliente_view(request, pk):
    if not peut_supprimer(request.user):
        return refuser_suppression(request)

    societe_cliente = get_object_or_404(
        SocieteCliente.objects.select_related("adresse", "societe"),
        pk=pk,
    )

    analyse = analyser_suppression(societe_cliente)
    objets_bloquants = analyse["bloquants"]
    objets_supprimes = analyse["supprimes"]

    if request.method == "POST":
        nom = societe_cliente.nom_societe_cliente or _("Sans nom")

        if objets_bloquants:
            messages.error(
                request,
                _("Impossible de supprimer « %(nom)s » : elle est encore utilisée ailleurs.") % {"nom": nom},
            )
            return redirect("societe_cliente:delete_societe_cliente", pk=pk)

        # Libellé pour le log (capturé AVANT la suppression)
        nom_log = nom
        if societe_cliente.numero_tva:
            nom_log += f" (TVA {societe_cliente.numero_tva})"
        nb_supprimes = sum(len(objets) for _label, objets in objets_supprimes)
        if nb_supprimes:
            detail = ", ".join(f"{len(objets)} {label}" for label, objets in objets_supprimes)
            nom_log += f" – supprimé(s) en cascade : {detail}"

        try:
            with transaction.atomic():
                adresse = societe_cliente.adresse
                societe_cliente.delete()

                # L'adresse est supprimée avec la société cliente
                if adresse:
                    adresse.delete()

                UserLog.objects.create(
                    utilisateur=request.user,
                    action=f"{ACTION_SUPPRESSION_SOCIETE_CLIENTE} : {nom_log}",
                )
        except (ProtectedError, RestrictedError):
            messages.error(
                request,
                _("Impossible de supprimer « %(nom)s » : la société ou son adresse est encore utilisée ailleurs.") % {"nom": nom},
            )
            return redirect("societe_cliente:delete_societe_cliente", pk=pk)

        messages.success(request, _("La société cliente « %(nom)s » a bien été supprimée.") % {"nom": nom})

        return redirect(
            f"{reverse('societe_cliente:societe_cliente_list')}?deleted=1"
        )

    return render(
        request,
        "societe_cliente/delete_societe_cliente.html",
        {
            "societe_cliente": societe_cliente,
            "objets_supprimes": objets_supprimes,
            "objets_bloquants": objets_bloquants,
            # Données sensibles masquées pour l'affichage
            "compte_masque": masquer(societe_cliente.numero_compte),
            "carte_bancaire_masquee": masquer(societe_cliente.numero_carte_bancaire),
        },
    )


