from django import forms
from .models import SocieteCliente
from django.utils.translation import gettext_lazy as _
from stdnum import iban as iban_lib

EU_VAT_PREFIXES = [
    "AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "EL", "ES",
    "FI", "FR", "HR", "HU", "IE", "IT", "LT", "LU", "LV", "MT",
    "NL", "PL", "PT", "RO", "SE", "SI", "SK"
]


def luhn_check(card_number: str) -> bool:
    """Vérifie si un numéro de carte est valide selon Luhn"""
    # Nettoyage
    card_number = card_number.replace(" ", "").replace("-", "")
    if not card_number.isdigit() or len(card_number) < 12:
        return False

    digits = [int(d) for d in card_number]
    check_digit = digits.pop()
    digits.reverse()

    for i in range(len(digits)):
        if i % 2 == 0:
            digits[i] *= 2
            if digits[i] > 9:
                digits[i] -= 9

    total = sum(digits) + check_digit
    return total % 10 == 0



class SocieteClienteForm(forms.ModelForm):
    # -------------------------
    # CHAMPS ADRESSE
    # -------------------------
    rue = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            "class": "border rounded px-4 py-2 w-full"
        })
    )

    numero = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            "class": "border rounded px-4 py-2 w-full"
        })
    )

    code_postal = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            "class": "border rounded px-4 py-2 w-full"
        })
    )
    boite = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            "class": "border rounded px-4 py-2 w-full"
        })
    )

    ville = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            "class": "border rounded px-4 py-2 w-full"
        })
    )

    pays = forms.CharField(
        required=False,
        initial="Belgique",
        widget=forms.TextInput(attrs={
            "class": "border rounded px-4 py-2 w-full"
        })
    )

    code_pays = forms.CharField(
        required=False,
        initial="BE",
        widget=forms.TextInput(attrs={
            "class": "border rounded px-4 py-2 w-full"
        })
    )

    class Meta:
        model = SocieteCliente

        fields = [
            "nom_societe_cliente",
            "directeur_nom_prenom",
            "numero_telephone",
            "email",
            "numero_tva",
            "numero_compte",
            "numero_carte_bancaire",
        ]

        widgets = {
            "nom_societe_cliente": forms.TextInput(attrs={
                "class": "border rounded px-4 py-2 w-full"
            }),

            "directeur_nom_prenom": forms.TextInput(attrs={
                "class": "border rounded px-4 py-2 w-full"
            }),

            "numero_telephone": forms.TextInput(attrs={
                "class": "border rounded px-4 py-2 w-full"
            }),

            "email": forms.EmailInput(attrs={
                "class": "border rounded px-4 py-2 w-full"
            }),

            "numero_tva": forms.TextInput(attrs={
                "class": "border rounded px-4 py-2 w-full"
            }),

            "numero_compte": forms.TextInput(attrs={
                "class": "border rounded px-4 py-2 w-full"
            }),

            "numero_carte_bancaire": forms.TextInput(attrs={
                "class": "border rounded px-4 py-2 w-full"
            }),
        }



    def clean_numero_tva(self):
        tva = (self.cleaned_data.get('numero_tva') or '').upper().replace(' ', '')

        if len(tva) < 2 or tva[:2] not in EU_VAT_PREFIXES:
            raise forms.ValidationError(
                _("Le numéro de TVA doit commencer par un code pays européen valide (ex: BE, FR, DE...).")
            )

        return tva




    def clean_numero_carte_bancaire(self):
        value = self.cleaned_data.get("numero_carte_bancaire")

        if not value:
            return None

        value = str(value).replace(" ", "").replace("-", "")

        if not value.isdigit():
            raise forms.ValidationError("Numéro de carte invalide")

        if not luhn_check(value):
            raise forms.ValidationError("Numéro de carte invalide (Luhn)")

        return value



    def clean_numero_compte(self):
        # IBAN : nettoyage (sans espaces, majuscules), longueur du pays et clé mod 97
        from core.iban import nettoyer_iban_formulaire
        return nettoyer_iban_formulaire(self.cleaned_data.get("numero_compte"))
