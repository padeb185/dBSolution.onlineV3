from django.urls import path
from .views import proprietaire_dashboard_view, ProprietaireListView, ProprietaireVoitureListView, \
    proprietaire_form_view, proprietaire_detail_view, proprietaire_voiture_form_view, \
    proprietaire_voiture_detail_view, total_part_voiture, modifier_proprietaire_view, \
    modifier_proprietaire_voiture_view, delete_proprietaire_view, delete_proprietaire_voiture_view

app_name = "proprietaire"

urlpatterns = [
    path('', proprietaire_dashboard_view, name='proprietaire_dashboard'),

    path('list/', ProprietaireListView.as_view(), name='proprietaire_list'),

    path("creer/",proprietaire_form_view, name="proprietaire_form",),

    path("<int:proprietaire_id>/", proprietaire_detail_view, name="proprietaire_detail"),

    path("<int:proprietaire_id>/modifier/",modifier_proprietaire_view,name="modifier_proprietaire"),

    path('proprietaire/', ProprietaireVoitureListView.as_view(), name='proprietaire_voiture_list'),

    path('proprietaire/creer/', proprietaire_voiture_form_view, name='proprietaire_voiture_form'),

    path("proprietaire/<int:proprietaire_voiture_id>/",proprietaire_voiture_detail_view,name="proprietaire_voiture_detail"),

    path("proprietaire/modifier/<int:proprietaire_voiture_id>/", modifier_proprietaire_voiture_view, name="modifier_proprietaire_voiture"),

    path("api/voiture/<int:voiture_id>/total-part/", total_part_voiture ,name="total_part_voiture"),

    path("<int:pk>/supprimer/", delete_proprietaire_view, name="delete_proprietaire"),

    path("parts/<int:pk>/supprimer/", delete_proprietaire_voiture_view, name="delete_proprietaire_voiture"),


]
