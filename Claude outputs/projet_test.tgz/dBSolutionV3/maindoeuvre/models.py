import uuid
from decimal import Decimal
from django.db import models
from django.utils.translation import gettext_lazy as _


class MainDoeuvre(models.Model):

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )

    societe = models.ForeignKey(
        "societe.Societe",
        on_delete=models.CASCADE,
        related_name="main_oeuvres",
        null=True,
        blank=True,
    )

    utilisateur = models.ForeignKey(
        "utilisateurs.Utilisateur",
        on_delete=models.SET_NULL,
        related_name="main_oeuvres",
        null=True,
        blank=True,
    )

    voiture_exemplaire = models.ForeignKey(
        "voiture_exemplaire.VoitureExemplaire",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="main_oeuvres",
        verbose_name=_("Véhicule"),
    )

    kilometres_chassis = models.PositiveIntegerField(
        default=0,
        null=True,
        blank=True,
        verbose_name=_("Kilomètres chassis")
    )

    # 💰 Prix facturé au client
    taux_horaire = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("50.00"),
        verbose_name="Taux horaire",
    )



    # ⏱ Temps total en minutes
    temps_minutes = models.PositiveIntegerField(default=0)

    descriptif = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )

    remarques = models.TextField(
        blank=True,
        null=True
    )

    date = models.DateTimeField(auto_now_add=True)

    created_at = models.DateTimeField(_("Créé le"), auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(_("Mis à jour le"), auto_now=True, blank=True, null=True)

    # -------------------------
    # TEMPS
    # -------------------------
    @property
    def heures(self):
        return self.temps_minutes // 60

    @property
    def minutes(self):
        return self.temps_minutes % 60

    @property
    def temps_decimal(self):
        return Decimal(self.temps_minutes) / Decimal(60)

    @property
    def temps_display(self):
        return f"{self.heures}h{self.minutes:02d}"

    # -------------------------
    # FACTURATION
    # -------------------------
    @property
    def cout_total(self):
        heures = Decimal(self.temps_minutes or 0) / Decimal("60")
        return (heures * self.taux_horaire).quantize(Decimal("0.01"))

    @property
    def taux_revient_horaire(self):
        """
        Coût de revient horaire du technicien (salaire total employeur / heures prestées),
        repris de sa paie du mois de l'intervention. À défaut : salaire brut / heure.
        """
        from utilisateurs.cout_main_oeuvre import cout_horaire_utilisateur

        if not hasattr(self, "_taux_revient_cache"):
            jour = self.date or self.created_at
            taux = cout_horaire_utilisateur(
                self.utilisateur,
                jour.year if jour else None,
                jour.month if jour else None,
            )
            if not taux:
                taux = getattr(self.utilisateur, "salaire_brut_heure", None) or Decimal("0.00")
            self._taux_revient_cache = Decimal(taux)
        return self._taux_revient_cache

    @property
    def cout_interne(self):
        return (self.temps_decimal * self.taux_revient_horaire).quantize(Decimal("0.01"))



    @property
    def cout_interne_display(self):
        cout = self.cout_interne or Decimal("0.00")
        return f"{cout.quantize(Decimal('0.01'))} €"

    @property
    def prix_facture(self):
        return self.cout_total

    def __str__(self):
        return f"{self.temps_display} - {self.utilisateur}"