from django.apps import AppConfig


class ClientPilotageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'client_pilotage'
