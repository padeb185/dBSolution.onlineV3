from django import forms
from django.core.exceptions import ValidationError
from django.utils import timezone
from .models import NettoyageExterieur
from maindoeuvre.models import MainDoeuvre
from django.utils.translation import gettext_lazy as _


class NettoyageExterieurForm(forms.ModelForm):
    temps_heures = forms.IntegerField(required=False, min_value=0)
    temps_minutes = forms.IntegerField(required=False, min_value=0, max_value=59)

    date = forms.DateTimeField(
        required=False,
        widget=forms.DateTimeInput(
            attrs={"readonly": "readonly", "class": "form-input"},
            format="%Y-%m-%d %H:%M:%S"
        )
    )

    kilometrage_variation = forms.IntegerField(
        required=False,
        label=_("Variation du kilométrage"),
        widget=forms.NumberInput(
            attrs={
                "readonly": "readonly",
                "class": "input",
            }
        ),
    )



    class Meta:
        model = NettoyageExterieur
        exclude = [
            "maintenance",
            "voiture_exemplaire",
            "created_at",
            "updated_at",
            "date",
            "kilometres_boite_rollback",
            "kilometres_moteur_rollback",
            "kilometres_embrayage_rollback",
            "kilometres_boite",
            "kilometres_moteur",
            "kilometres_embrayage",
        ]

        widgets = {
            "remarques": forms.Textarea(attrs={
                "rows": 4,
                "placeholder": "Ajoutez des remarques ici..."
            }),
            "kilometres_chassis": forms.NumberInput(
                attrs={
                    "readonly": "readonly",
                    "class": "bg-gray-100 cursor-not-allowed",
                }
            ),
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop("user", None)
        self.exemplaire = kwargs.pop("exemplaire", None)
        super().__init__(*args, **kwargs)

        # =========================
        # VARIATION KILOMÉTRAGE
        # =========================
        if "kilometrage_variation" in self.fields:

            variation = 0

            if (
                    self.instance
                    and self.instance.pk
                    and self.instance.kilometrage_net_ext is not None
            ):
                # À adapter suivant l'endroit où tu stockes
                # le kilométrage précédent
                variation = self.instance.kilometrage_variation or 0

            self.fields["kilometrage_variation"].initial = variation





        if "main_oeuvre" in self.fields:
            self.fields["main_oeuvre"].queryset = MainDoeuvre.objects.select_related(
                "utilisateur"
            ).filter(utilisateur__is_active=True)
            self.fields["main_oeuvre"].widget.attrs.update({"class": "input"})

        if self.instance and self.instance.main_oeuvre:
            mo = self.instance.main_oeuvre
            self.fields["temps_heures"].initial = mo.heures
            self.fields["temps_minutes"].initial = mo.minutes

        if self.instance and self.instance.pk and self.instance.date:
            local_dt = timezone.localtime(self.instance.date)
            self.fields["date"].initial = local_dt.strftime("%Y-%m-%d %H:%M:%S")

        if self.user:
            if "tech_technicien" in self.fields:
                self.fields["tech_technicien"].initial = self.user
                self.fields["tech_technicien"].disabled = True

            if "tech_nom_technicien" in self.fields:
                self.fields["tech_nom_technicien"].initial = f"{self.user.prenom} {self.user.nom}"
                self.fields["tech_nom_technicien"].disabled = True

            if "tech_role_technicien" in self.fields:
                self.fields["tech_role_technicien"].initial = self.user.role
                self.fields["tech_role_technicien"].disabled = True

            if "tech_societe" in self.fields:
                self.fields["tech_societe"].initial = self.user.societe
                self.fields["tech_societe"].disabled = True




    def clean_kilometrage_net_ext(self):
        km = self.cleaned_data.get("kilometrage_net_ext")

        if km is not None and self.exemplaire:
            if km < self.exemplaire.kilometres_chassis:
                raise ValidationError("Le kilométrage ne peut pas diminuer.")

        return km



    def clean(self):
        cleaned = super().clean()

        h = cleaned.get("temps_heures") or 0
        m = cleaned.get("temps_minutes") or 0

        if m >= 60:
            raise ValidationError("Les minutes ne peuvent pas dépasser 59.")

        return cleaned




    def save(self, commit=True):
        instance = super().save(commit=False)

        if self.exemplaire:
            instance.voiture_exemplaire = self.exemplaire
            instance.kilometres_chassis = self.exemplaire.kilometres_chassis

        if self.user:
            instance.assign_technicien(self.user)
            instance._user = self.user

        km = self.cleaned_data.get("kilometrage_net_ext")

        if km is not None:
            instance.kilometrage_net_ext = km
            instance.kilometres_chassis = km

        heures = self.cleaned_data.get("temps_heures") or 0
        minutes = self.cleaned_data.get("temps_minutes") or 0
        total_minutes = heures * 60 + minutes

        main = instance.main_oeuvre

        if total_minutes > 0:
            if main:
                main.temps_minutes = total_minutes
                main.save(update_fields=["temps_minutes"])
            else:
                main = MainDoeuvre.objects.create(
                    utilisateur=self.user,
                    temps_minutes=total_minutes
                )
                instance.main_oeuvre = main

        if commit:
            instance.save()

        return instance