from django.urls import path, include
from utilisateurs.views import dashboard_view
from voiture.voiture_exemplaire.views import ajouter_exemplaire

urlpatterns = [
    # Dashboard principal
    path("dashboard/", dashboard_view, name="dashboard"),



    # Exemplaires de voiture
    path(
        "exemplaires/",
        include(("voiture.voiture_exemplaire.urls", "voiture_exemplaire"), namespace="voiture_exemplaire")
    ),

    # Ajouter un exemplaire pour un modèle spécifique
    path(
        "modele/<uuid:modele_id>/ajouter/",
        ajouter_exemplaire,
        name="ajouter_exemplaire"
    ),

    # Moteurs

    path("voiture/", include(("tenant.urls", "tenant"), namespace="tenant")),

    path(
        "tenant/voiture/exemplaire/",
        include("voiture.voiture_exemplaire.urls")
    ),






]
