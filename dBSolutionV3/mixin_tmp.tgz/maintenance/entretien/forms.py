from django import forms
from maintenance.obligatoires import ChampsObligatoiresMaintenanceMixin
from django.core.exceptions import ValidationError
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from .models import Entretien
from maindoeuvre.models import MainDoeuvre
from ..choices import RouesSerrageEtat


class EntretienForm(ChampsObligatoiresMaintenanceMixin, forms.ModelForm):

    temps_heures = forms.IntegerField(required=False, min_value=0)
    temps_minutes = forms.IntegerField(required=False, min_value=0, max_value=59)

    kilometrage_variation = forms.IntegerField(
        required=False,
        label=_("Variation du kilométrage"),
        widget=forms.NumberInput(
            attrs={
                "readonly": "readonly",
                "class": "input",
            }
        ),
    )

    class Meta:
        model = Entretien

        exclude =  {
            "kilometres_boite_rollback",
            "kilometres_moteur_rollback",
            "kilometres_embrayage_rollback",
            "kilometres_boite",
            "kilometres_moteur",
            "kilometres_embrayage",
            "kilometres_dernier_entretien",
            "pieces",
        }
        widgets = {
            "maintenance": forms.HiddenInput(),
            "remarques": forms.Textarea(attrs={
                "rows": 4,
                "placeholder": _("Ajoutez des remarques ici...")
            }),
            "pneu_pression_bar_avd": forms.NumberInput(
                attrs={"step": "0.1"}
            ),
            "pneu_pression_bar_avg": forms.NumberInput(
                attrs={"step": "0.1"}
            ),
            "pneu_pression_bar_ard": forms.NumberInput(
                attrs={"step": "0.1"}
            ),
            "pneu_pression_bar_arg": forms.NumberInput(
                attrs={"step": "0.1"}
            ),
            "kilometres_chassis": forms.NumberInput(
                attrs={
                    "readonly": "readonly",
                    "class": "bg-gray-100 cursor-not-allowed",
                }
            ),
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop("user", None)
        self.exemplaire = kwargs.pop("exemplaire", None)
        super().__init__(*args, **kwargs)

        # =========================
        # CHAMPS ABSENTS DU POST
        # =========================
        # Si un champ du modèle possède une valeur par défaut et
        # qu'il n'a pas été envoyé par la page (section non affichée),
        # on ne bloque pas la validation : Django conservera la
        # valeur par défaut du modèle lors de l'enregistrement.
        if self.is_bound:
            for nom, champ in self.fields.items():
                try:
                    champ_modele = self._meta.model._meta.get_field(nom)
                except Exception:
                    continue

                if not champ_modele.has_default():
                    continue

                if champ.widget.value_omitted_from_data(
                    self.data, self.files, self.add_prefix(nom)
                ):
                    champ.required = False

        # =========================
        # VARIATION KILOMÉTRAGE
        # =========================
        if "kilometrage_variation" in self.fields:

            variation = 0

            # =========================
            # INSTANCE EXISTANTE
            # =========================
            if self.instance:

                ancien_km = (
                        self.instance.kilometres_chassis or 0
                )

                nouveau_km = (
                    self.instance.kilometrage_entretien
                )

                if nouveau_km is not None:
                    variation = nouveau_km - ancien_km

            self.fields["kilometrage_variation"].initial = variation




        # -------- INITIALISATION TEMPS --------
        if self.instance and self.instance.pk and self.instance.main_oeuvre:
            total = self.instance.main_oeuvre.temps_minutes

            self.fields["temps_heures"].initial = total // 60
            self.fields["temps_minutes"].initial = total % 60





        # -------- MAIN D'ŒUVRE QUERYSET --------
        if "main_oeuvre" in self.fields:
            self.fields["main_oeuvre"].queryset = MainDoeuvre.objects.select_related(
                "utilisateur"
            ).filter(utilisateur__is_active=True)

            self.fields["main_oeuvre"].widget.attrs.update({
                "class": "input"
            })




        # -------- DATE --------
        if "date" in self.fields and self.instance and self.instance.pk and self.instance.date:
            local_dt = timezone.localtime(self.instance.date)
            self.fields["date"].initial = local_dt.strftime("%Y-%m-%d %H:%M:%S")

        # -------- TECH --------
        if self.user:
            if "tech_technicien" in self.fields:
                self.fields["tech_technicien"].initial = self.user
                self.fields["tech_technicien"].disabled = True

            if "tech_societe" in self.fields:
                self.fields["tech_societe"].initial = self.user.societe
                self.fields["tech_societe"].disabled = True



    def clean_kilometrage_entretien(self):
        km = self.cleaned_data.get("kilometrage_entretien")
        exemplaire = self.exemplaire

        if km is not None and exemplaire:
            if km < exemplaire.kilometres_chassis:
                raise ValidationError(
                    "Le kilométrage ne peut pas diminuer."
                )

        return km


    def save(self, commit=True):
        instance = super().save(commit=False)

        km = self.cleaned_data.get("kilometrage_entretien")
        voiture = self.exemplaire

        if km is not None and voiture:
            instance.kilometrage_entretien = km
            instance.voiture_exemplaire = voiture

        # -------- MAIN D'ŒUVRE --------
        heures = self.cleaned_data.get("temps_heures") or 0
        minutes = self.cleaned_data.get("temps_minutes") or 0

        total_minutes = heures * 60 + minutes

        main = instance.main_oeuvre

        if main:
            main.temps_minutes = total_minutes
            main.save(update_fields=["temps_minutes"])
        else:
            main = MainDoeuvre.objects.create(
                utilisateur=self.user,
                temps_minutes=total_minutes
            )
            instance.main_oeuvre = main

        # -------- SAVE FINAL --------
        if commit:
            instance.save()

        return instance




